package global.sesoc.library.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;

import global.sesoc.library.dto.Book;
import global.sesoc.library.dto.BookPenalty;
import global.sesoc.library.dto.BookView;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.MemberView;
import global.sesoc.library.dto.RentBook;

public interface BookDao {

	public int insertBook(Book book);

	public List<Book> selectAll();

	public Book selectOne(int booknum);

	public int deleteBook(int booknum);

	public int updateBook(Book book);

	public int recordCount();

	public List<Book> searchNum(String searchWord);

	public List<Book> searchTitle(String searchWord);

	public List<Book> searchWriter(String searchWord);

	public List<Book> searchPublisher(String searchWord);

	public Book bookcodeCheck(String bookcode);

	public List<Book> searchBook(Map<String, Object> map, RowBounds rb);

	public int getTotalBook(Map<String, String> map);

	public Member searchUserId(String userid);

	public List<RentBook> searchRentInfo(String userid);

	public Book searchBookInfo(String bookcode);

	public RentBook searchRentInfo2(int booknum);

	public int rentBook(Map<String, Object> map);

	public void updateStatus(int booknum);

	public BookPenalty bookPenalty(String userid);

	public int rbCheck(int booknum);

	public List<String> checkOver();
	
	public BookPenalty checkBookPenal(String userid);
	
	public int insertBP(String userid);
	
	public int updateBP(String userid);
	
	public List<Integer> checkOverBook();
	
	public int updateOverBook(int booknum);

	public void returnBook(int booknum);

	public void returnRentBook(int booknum);

	public void returnBook2(int booknum);

	public void returnRentBook2(int booknum);

	public void updateBookcount(String userid);

	public List<RentBook> countCheck(String userid);

	public List<Book> allBookList();

	public List<RentBook> allRentList();

	public List<BookView> getBookView(Map<String, Object> map, RowBounds rb);

	public List<MemberView> getMemberView(Map<String, Object> map, RowBounds rb);

	public BookView selectOne098(int booknum);
	
	public List<Book> getNewBook();
	
	public int getTotalMember1(Map<String, Object> map);

	public int getTotalBook1(Map<String, Object> map);

	public int searchCount(String searchWord);

	public int searchWriterCount(String searchWord);

	public int searchBookcodeCount(String searchWord);

	public int searchPublisherCount(String searchWord);

	
}
