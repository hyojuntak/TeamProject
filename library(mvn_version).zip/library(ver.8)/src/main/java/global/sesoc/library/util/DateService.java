package global.sesoc.library.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateService {
	public static String getToday() {
	      SimpleDateFormat dateform = new SimpleDateFormat("YYYY-MM-dd");
	      Calendar c = Calendar.getInstance();
	      String today = dateform.format(c.getTime());
	      return today;
	}
	
	public static String getFullToday() {
		SimpleDateFormat dateform = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
		Calendar c = Calendar.getInstance();
		String fullToday = dateform.format(c.getTime());
		return fullToday;
	}
	
	public static String getSimpleToday() {
		SimpleDateFormat dateform = new SimpleDateFormat("YYYYMMddHHmmss");
		Calendar c = Calendar.getInstance();
		String fullToday = dateform.format(c.getTime());
		return fullToday;
	}
}
