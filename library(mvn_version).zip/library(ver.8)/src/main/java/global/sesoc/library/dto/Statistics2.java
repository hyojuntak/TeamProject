package global.sesoc.library.dto;

public class Statistics2 {
	private Integer weekday;
	private Integer checktime;
	private Integer rscount;
	private Integer wpcount;

	public Statistics2() {
		// TODO Auto-generated constructor stub
	}
	
	public Statistics2(Integer weekday, Integer checktime, Integer rscount, Integer wpcount) {
		super();
		this.weekday = weekday;
		this.checktime = checktime;
		this.rscount = rscount;
		this.wpcount = wpcount;
	}

	public Integer getWeekday() {
		return weekday;
	}

	public void setWeekday(Integer weekday) {
		this.weekday = weekday;
	}

	public Integer getChecktime() {
		return checktime;
	}

	public void setChecktime(Integer checktime) {
		this.checktime = checktime;
	}

	public Integer getRscount() {
		return rscount;
	}

	public void setRscount(Integer rscount) {
		this.rscount = rscount;
	}

	public Integer getWpcount() {
		return wpcount;
	}

	public void setWpcount(Integer wpcount) {
		this.wpcount = wpcount;
	}

	@Override
	public String toString() {
		return "Statistics2 [weekday=" + weekday + ", checktime=" + checktime + ", rscount=" + rscount + ", wpcount="
				+ wpcount + "]";
	}
}
