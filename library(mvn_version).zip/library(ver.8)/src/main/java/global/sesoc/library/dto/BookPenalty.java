package global.sesoc.library.dto;

public class BookPenalty {
	private int bpnum;
	private String userid;
	private String startdate;
	private String enddate;
	
	public BookPenalty() {
		// TODO Auto-generated constructor stub
	}

	public BookPenalty(int bpnum, String userid, String startdate, String enddate) {
		super();
		this.bpnum = bpnum;
		this.userid = userid;
		this.startdate = startdate;
		this.enddate = enddate;
	}

	public int getBpnum() {
		return bpnum;
	}

	public void setBpnum(int bpnum) {
		this.bpnum = bpnum;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "BookPenalty [bpnum=" + bpnum + ", userid=" + userid + ", startdate=" + startdate + ", enddate="
				+ enddate + "]";
	}
	
}
