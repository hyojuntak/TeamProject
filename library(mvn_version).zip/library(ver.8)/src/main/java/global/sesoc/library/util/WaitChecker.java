package global.sesoc.library.util;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import global.sesoc.library.dao.StudyDao;
import global.sesoc.library.dto.Seat;
import global.sesoc.library.dto.WaitPaper;

public class WaitChecker extends Thread {
	private static SqlSessionFactory factory;
	private boolean flag;
	
	public WaitChecker() {
		factory = MybatisConfig.getSqlSessionFactory();
		flag = false;
	}
	
	public void turnOff() {
		flag = true;
	}
	
	@Override
	public void run() {
		SqlSession session = null;
		
		try {
			session = factory.openSession();
			StudyDao dao = session.getMapper(StudyDao.class);
			
			while(true) {
				List<WaitPaper> unablelist = dao.getUnableWait(DateService.getFullToday());
				
				if(unablelist.size() > 0) {
					List<Seat> ableseat = dao.getAbleSeat();
					List<WaitPaper> ablelist = dao.getAbleWait(DateService.getFullToday());
					
					if(ableseat.size() - ablelist.size() > 0) {
						for(int i = 0; i < ableseat.size() - ablelist.size(); i++) {
							
							if(unablelist.size() - i <= 0) {
								break;
							}
							
							dao.updateAbleWait(unablelist.get(i));
							session.commit();
						}
					}
				}
				
				if(flag) {
					break;
				}
				
				Thread.sleep(1000 * 60);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) {
				session.commit();
				session.close();
			}
		}
	}
}
