package global.sesoc.library.dto;

import java.util.List;

public class UserInfo {
	
	private Member member;
	private List<RentBook> rentbook;
	private List<Complain> complain;
	
	public UserInfo() {
		// TODO Auto-generated constructor stub
	}

	public UserInfo(Member member, List<RentBook> rentbook, List<Complain> complain) {
		super();
		this.member = member;
		this.rentbook = rentbook;
		this.complain = complain;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public List<RentBook> getRentbook() {
		return rentbook;
	}

	public void setRentbook(List<RentBook> rentbook) {
		this.rentbook = rentbook;
	}

	public List<Complain> getComplain() {
		return complain;
	}

	public void setComplain(List<Complain> complain) {
		this.complain = complain;
	}

	@Override
	public String toString() {
		return "UserInfo [member=" + member + ", rentbook=" + rentbook + ", complain=" + complain + "]";
	}

	
}
