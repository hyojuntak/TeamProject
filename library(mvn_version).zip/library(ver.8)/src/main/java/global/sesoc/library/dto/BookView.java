package global.sesoc.library.dto;

public class BookView {
	private int booknum;
	private String bookcode;
	private String title;
	private String writer;
	private String publisher;
	private String originfile;
	private String savedfile;
	private int status; // 대출 상태
	private String statusView;
	private String rentdate;
	private String enddate;

	public BookView() {
		// TODO Auto-generated constructor stub
	}

	public BookView(int booknum, String bookcode, String title, String writer, String publisher, String originfile,
			String savedfile, int status, String statusView, String rentdate, String enddate) {
		super();
		this.booknum = booknum;
		this.bookcode = bookcode;
		this.title = title;
		this.writer = writer;
		this.publisher = publisher;
		this.originfile = originfile;
		this.savedfile = savedfile;
		this.status = status;
		this.statusView = statusView;
		this.rentdate = rentdate;
		this.enddate = enddate;
	}

	public int getBooknum() {
		return booknum;
	}

	public void setBooknum(int booknum) {
		this.booknum = booknum;
	}

	public String getBookcode() {
		return bookcode;
	}

	public void setBookcode(String bookcode) {
		this.bookcode = bookcode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getOriginfile() {
		return originfile;
	}

	public void setOriginfile(String originfile) {
		this.originfile = originfile;
	}

	public String getSavedfile() {
		return savedfile;
	}

	public void setSavedfile(String savedfile) {
		this.savedfile = savedfile;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getStatusView() {
		return statusView;
	}

	public void setStatusView(String statusView) {
		this.statusView = statusView;
	}

	public String getRentdate() {
		return rentdate;
	}

	public void setRentdate(String rentdate) {
		this.rentdate = rentdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "BookView [booknum=" + booknum + ", bookcode=" + bookcode + ", title=" + title + ", writer=" + writer
				+ ", publisher=" + publisher + ", originfile=" + originfile + ", savedfile=" + savedfile + ", status="
				+ status + ", statusView=" + statusView + ", rentdate=" + rentdate + ", enddate=" + enddate + "]";
	}

	
}
