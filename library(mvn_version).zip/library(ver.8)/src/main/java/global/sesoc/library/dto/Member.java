package global.sesoc.library.dto;

public class Member {
	private String userid;
	private int usertype;
	private String username;
	private String userpwd;
	private String phone;
	private String birth;
	private String originfile;
	private String savedfile;
	private int bookcount;

	public Member() {
		// TODO Auto-generated constructor stub
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int getUsertype() {
		return usertype;
	}

	public void setUsertype(int usertype) {
		this.usertype = usertype;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getOriginfile() {
		return originfile;
	}

	public void setOriginfile(String originfile) {
		this.originfile = originfile;
	}

	public String getSavedfile() {
		return savedfile;
	}

	public void setSavedfile(String savedfile) {
		this.savedfile = savedfile;
	}

	public int getBookcount() {
		return bookcount;
	}

	public void setBookcount(int bookcount) {
		this.bookcount = bookcount;
	}

	@Override
	public String toString() {
		return "Member [userid=" + userid + ", usertype=" + usertype + ", username=" + username + ", userpwd=" + userpwd
				+ ", phone=" + phone + ", birth=" + birth + ", originfile=" + originfile + ", savedfile=" + savedfile
				+ ", bookcount=" + bookcount + "]";
	}
}
