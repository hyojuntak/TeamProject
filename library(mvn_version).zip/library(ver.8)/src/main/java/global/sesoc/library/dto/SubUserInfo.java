package global.sesoc.library.dto;

public class SubUserInfo {
	private int seatnum;
	private String username;
	private String birth;
	private String phone;
	private String originfile;
	private String savedfile;
	private String renttime;

	public SubUserInfo() {
		// TODO Auto-generated constructor stub
	}

	public int getSeatnum() {
		return seatnum;
	}

	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getOriginfile() {
		return originfile;
	}

	public void setOriginfile(String originfile) {
		this.originfile = originfile;
	}

	public String getSavedfile() {
		return savedfile;
	}

	public void setSavedfile(String savedfile) {
		this.savedfile = savedfile;
	}

	public String getRenttime() {
		return renttime;
	}

	public void setRenttime(String renttime) {
		this.renttime = renttime;
	}

	@Override
	public String toString() {
		return "SubUserInfo [seatnum=" + seatnum + ", username=" + username + ", birth=" + birth + ", phone=" + phone
				+ ", originfile=" + originfile + ", savedfile=" + savedfile + ", renttime=" + renttime + "]";
	}
}
