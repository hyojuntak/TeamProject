package global.sesoc.library.dao;

import java.util.List;

import global.sesoc.library.dto.Complain;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.RentBook;

public interface MemberDao {
	public Member selectOne(Member member);

	public int insertJoin(Member member);
	
	public int updatePwd(Member member);
	
	public int deleteMember(Member member);
	
	public int updateUserInfo(Member member);
	
	//민주
		// ID이용자 조회
		public List<RentBook> selectRentbook(String userid); //도서대여 조회
		public List<Complain> selectComplain(String userid); //컴플레인 조회
}
