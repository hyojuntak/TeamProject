package global.sesoc.library.dto;

public class Seat {
	private int seatnum;
	private int desknum;
	private int status;
	private int ups;
	private int downs;
	private int lefts;
	private int rights;
	private String abstime;
	private int sensornum;

	public Seat() {
		// TODO Auto-generated constructor stub
	}

	public int getSeatnum() {
		return seatnum;
	}

	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}

	public int getDesknum() {
		return desknum;
	}

	public void setDesknum(int desknum) {
		this.desknum = desknum;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getUps() {
		return ups;
	}

	public void setUps(int ups) {
		this.ups = ups;
	}

	public int getDowns() {
		return downs;
	}

	public void setDowns(int downs) {
		this.downs = downs;
	}

	public int getLefts() {
		return lefts;
	}

	public void setLefts(int lefts) {
		this.lefts = lefts;
	}

	public int getRights() {
		return rights;
	}

	public void setRights(int rights) {
		this.rights = rights;
	}

	public String getAbstime() {
		return abstime;
	}

	public void setAbstime(String abstime) {
		this.abstime = abstime;
	}

	public int getSensornum() {
		return sensornum;
	}

	public void setSensornum(int sensornum) {
		this.sensornum = sensornum;
	}

	@Override
	public String toString() {
		return "Seat [seatnum=" + seatnum + ", desknum=" + desknum + ", status=" + status + ", ups=" + ups + ", downs="
				+ downs + ", lefts=" + lefts + ", rights=" + rights + ", abstime=" + abstime + ", sensornum="
				+ sensornum + "]";
	}
}
