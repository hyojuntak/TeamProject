package global.sesoc.library.dto;

public class SeatUser {
	private int seatnum;
	private String upsid;
	private String downsid;
	private String leftsid;
	private String rightsid;

	public SeatUser() {
		// TODO Auto-generated constructor stub
	}

	public int getSeatnum() {
		return seatnum;
	}

	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}

	public String getUpsid() {
		return upsid;
	}

	public void setUpsid(String upsid) {
		this.upsid = upsid;
	}

	public String getDownsid() {
		return downsid;
	}

	public void setDownsid(String downsid) {
		this.downsid = downsid;
	}

	public String getLeftsid() {
		return leftsid;
	}

	public void setLeftsid(String leftsid) {
		this.leftsid = leftsid;
	}

	public String getRightsid() {
		return rightsid;
	}

	public void setRightsid(String rightsid) {
		this.rightsid = rightsid;
	}

	@Override
	public String toString() {
		return "SeatUser [seatnum=" + seatnum + ", upsid=" + upsid + ", downsid=" + downsid + ", leftsid=" + leftsid
				+ ", rightsid=" + rightsid + "]";
	}
}
