package global.sesoc.library.dto;

public class WaitPaper {
	private int papernum;
	private String waitdate;
	private int waitnum;
	private String userid;
	private String issuetime;
	private String abletime;
	private String expiretime;
	private String usetime;

	public WaitPaper() {
		// TODO Auto-generated constructor stub
	}

	public int getPapernum() {
		return papernum;
	}

	public void setPapernum(int papernum) {
		this.papernum = papernum;
	}

	public String getWaitdate() {
		return waitdate;
	}

	public void setWaitdate(String waitdate) {
		this.waitdate = waitdate;
	}

	public int getWaitnum() {
		return waitnum;
	}

	public void setWaitnum(int waitnum) {
		this.waitnum = waitnum;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getIssuetime() {
		return issuetime;
	}

	public void setIssuetime(String issuetime) {
		this.issuetime = issuetime;
	}

	public String getAbletime() {
		return abletime;
	}

	public void setAbletime(String abletime) {
		this.abletime = abletime;
	}

	public String getExpiretime() {
		return expiretime;
	}

	public void setExpiretime(String expiretime) {
		this.expiretime = expiretime;
	}

	public String getUsetime() {
		return usetime;
	}

	public void setUsetime(String usetime) {
		this.usetime = usetime;
	}

	@Override
	public String toString() {
		return "WaitPaper [papernum=" + papernum + ", waitdate=" + waitdate + ", waitnum=" + waitnum + ", userid="
				+ userid + ", issuetime=" + issuetime + ", abletime=" + abletime + ", expiretime=" + expiretime
				+ ", usetime=" + usetime + "]";
	}
}
