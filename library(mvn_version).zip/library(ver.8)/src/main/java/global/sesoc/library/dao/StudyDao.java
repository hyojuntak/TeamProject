package global.sesoc.library.dao;

import java.util.List;
import java.util.Map;

import global.sesoc.library.dto.Desk;
import global.sesoc.library.dto.PortName;
import global.sesoc.library.dto.Reliability;
import global.sesoc.library.dto.RentSeat;
import global.sesoc.library.dto.Seat;
import global.sesoc.library.dto.SeatPenalty;
import global.sesoc.library.dto.SeatUser;
import global.sesoc.library.dto.Statistics1;
import global.sesoc.library.dto.Statistics2;
import global.sesoc.library.dto.SubUserInfo;
import global.sesoc.library.dto.WaitPaper;

public interface StudyDao {
	public List<Desk> getAllDesk(int location);
	
	public List<Seat> getAllSeat(int location);
	
	public List<WaitPaper> getAllWait(String now);
	
	public List<WaitPaper> getUnableWait(String now);
	
	public List<WaitPaper> getAbleWait(String now);
	
	public SubUserInfo getSubUserInfo(int seatnum);
	
	public int insertRentSeat(RentSeat rs);
	
	public RentSeat getRentPaper(String userid);
	
	public List<Seat> getAbleSeat();
	
	public List<WaitPaper> getAllPaper();
	
	public int insertWait(WaitPaper waitpaper);
	
	public RentSeat getUsingSeat(String userid);
	
	public WaitPaper getWaitPaper(String userid);
	
	public WaitPaper getWaitInfo(String userid);
	
	public int updateSeatStatus(Map<String, Object> map);
	
	public int returnSeat(Map<String, Object> map);
	
	public int updateAbleWait(WaitPaper wp);
	
	public int useWait(WaitPaper wp);
	
	// ============================ 통계
	
	public List<Statistics1> getSta1();
	
	public Statistics2 getSta2(Statistics2 sta2);
	
	// ============================
	
	public int returnSeat2(int seatnum);
	
	public String getSeatUserid(int seatnum);
	
	public List<Seat> getEverySeat();
	
	public int regAbstime(int seatnum);
	
	// ========================= 기초 데이터 쌓기
	
	public int regBaseData(int basedata);
	
	// =========================
	
	public List<PortName> getPortNames();
	
	public int insertPortNames(PortName portname);
	
	public PortName getPortName(int seatnum);
	
	public Reliability getReliability();
	
	public SeatPenalty getSP0(String userid);
	
	public List<SeatPenalty> getSP1(String userid);
	
	public SeatUser checkPartner(int seatnum);
	
	public WaitPaper getAbleWaitById(String userid);
	
	public String getSendPhone(String userid);
}
