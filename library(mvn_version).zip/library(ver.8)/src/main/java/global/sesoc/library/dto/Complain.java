package global.sesoc.library.dto;

public class Complain {
	private int compnum;	
	private String regtime;
	private int comptype;
	private String title;
	private String content;
	private String reguser;
	private String target;
	private String target2;
	
	public Complain() {

	}

	public Complain(int compnum, String regtime, int comptype, String title, String content, String reguser,
			String target, String target2) {
		super();
		this.compnum = compnum;
		this.regtime = regtime;
		this.comptype = comptype;
		this.title = title;
		this.content = content;
		this.reguser = reguser;
		this.target = target;
		this.target2 = target2;
	}

	public int getCompnum() {
		return compnum;
	}

	public String getRegtime() {
		return regtime;
	}

	public int getComptype() {
		return comptype;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}

	public String getReguser() {
		return reguser;
	}

	public String getTarget() {
		return target;
	}

	public String getTarget2() {
		return target2;
	}

	public void setCompnum(int compnum) {
		this.compnum = compnum;
	}

	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}

	public void setComptype(int comptype) {
		this.comptype = comptype;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setReguser(String reguser) {
		this.reguser = reguser;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public void setTarget2(String target2) {
		this.target2 = target2;
	}

	@Override
	public String toString() {
		return "Complain [compnum=" + compnum + ", regtime=" + regtime + ", comptype=" + comptype + ", title=" + title
				+ ", content=" + content + ", reguser=" + reguser + ", target=" + target + ", target2=" + target2 + "]";
	}
	
	
	
}
