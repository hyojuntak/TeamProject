drop table seatpenalty;
drop table bookpenalty;
drop table complain;
drop table rentseat;
drop table rentbook;
drop table waitpaper;
drop table seat;
drop table desk;
drop table book;
drop table member;
drop table basedata;
drop table portnames;

drop sequence desk_seq;
drop sequence seat_seq;
drop sequence book_seq;
drop sequence wait_seq;
drop sequence rb_seq;
drop sequence rs_seq;
drop sequence comp_seq;
drop sequence bp_seq;
drop sequence sp_seq;
drop sequence sen_seq;
drop sequence bd_seq;

create table member (
  userid varchar2(30) primary key,
  usertype number default 2 not null,
  username varchar2(50) not null,
  userpwd varchar2(30) not null,
  phone varchar2(20) not null,
  birth date not null,
  originfile varchar2(100) not null,
  savedfile varchar2(200) not null,
  bookcount number default 0 not null
);

create table book (
  booknum number primary key,
  bookcode varchar2(50),
  bookid number,
  status number default 1,
  title varchar2(200),
  writer varchar2(50),
  publisher varchar2(50),
  pubdate date,
  originfile varchar2(100),
  savedfile varchar2(200)
);

create table desk (
  desknum number primary key,
  location number
);

create table seat (
  seatnum number primary key,
  desknum number not null,
  status number default 1,
  ups number default 0,
  downs number default 0,
  lefts number default 0,
  rights number default 0,
  abstime date default null,
  sensornum number default 0,
  foreign key(desknum) references desk on delete cascade
);

create table waitpaper (
  papernum number primary key,
  waitdate date default sysdate,
  waitnum number,
  userid varchar2(30) not null,
  issuetime date default sysdate,
  abletime date,
  expiretime date,
  usetime date,
  foreign key(userid) references member on delete cascade
);

create table rentbook (
  rbnum number primary key,
  userid varchar2(30) references member on delete cascade,
  booknum number references book on delete cascade,
  status number default 0,
  rentdate date default sysdate,
  enddate date default sysdate + 14,
  returndate date,
  rentperiod number,
  check (userid is not null),
  check (booknum is not null)
);

create table rentseat (
  rsnum number primary key,
  userid varchar2(30) references member on delete cascade,
  seatnum number references seat,
  status number default 0,
  renttime date default sysdate,
  returntime date,
  rentperiod number,
  check (userid is not null),
  check (seatnum is not null)
);

create table complain (
  compnum number primary key,
  reguser varchar2(30) references member on delete cascade,
  target varchar2(30) references member on delete cascade,
  target2 varchar2(30) references member on delete cascade,
  regtime date default sysdate,
  comptype number,
  title varchar2(200) not null,
  content varchar2(2000) not null,
  check (reguser is not null)
);

create table bookpenalty (
  bpnum number primary key,
  userid varchar2(30) references member on delete cascade,
  startdate date default sysdate,
  enddate date default sysdate + 14,
  check (userid is not null)
);

create table seatpenalty (
  spnum number primary key,
  userid varchar2(30) references member on delete cascade,
  userid2 varchar2(30) references member on delete cascade,
  penaltytype number default 0,
  startdate date default sysdate,
  enddate date default sysdate + 7,
  check (userid is not null)
);

create sequence bd_seq;
create table basedata (
  bdnum number primary key,
  regtime date default sysdate,
  regdata number
);

create table portnames (
  seatnum number primary key,
  portname varchar2(500)
);

create sequence desk_seq;
create sequence seat_seq;
create sequence book_seq;
create sequence wait_seq;
create sequence rb_seq;
create sequence rs_seq;
create sequence comp_seq;
create sequence bp_seq;
create sequence sp_seq;
create sequence sen_seq;

insert into member
values('aaaa', 1, 'manager', 'aaaa', '010-1111-1111', sysdate, 'a', 'a', 0);

insert into member
values('bbbb', 2, 'guest', 'bbbb', '010-2222-2222', sysdate, 'b', 'b', 0);

insert into member
values('bbbb1', 2, 'guest', 'bbbb1', '010-2222-2229', sysdate, 'b1', 'b1', 0);

insert into member
values('bbbb2', 2, 'guest', 'bbbb2', '010-2222-2228', sysdate, 'b2', 'b2', 0);

insert into member
values('bbbb3', 2, 'guest', 'bbbb3', '010-2222-2227', sysdate, 'b3', 'b3', 0);

insert into member
values('bbbb4', 2, 'guest', 'bbbb4', '010-2222-2226', sysdate, 'b4', 'b4', 0);

insert into book
values(book_seq.nextval, '815.205.o55x', 1, 1, 'ccc', 'ccc', 'ccc', sysdate, 'c', 'c');

insert into book
values(book_seq.nextval, '511.115.s312x', 2, 1, 'ddd', 'ddd', 'ddd', sysdate, 'd', 'd');

insert into desk values(desk_seq.nextval, 1);

insert into seat values(seat_seq.nextval, 1, 1, 0, 4, 0, 2, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 1, 1, 0, 5, 1, 3, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 1, 1, 0, 6, 2, 0, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 1, 1, 1, 0, 0, 5, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 1, 1, 2, 0, 4, 6, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 1, 1, 3, 0, 5, 0, null, sen_seq.nextval);

insert into desk values(desk_seq.nextval, 1);

insert into seat values(seat_seq.nextval, 2, 1, 0, 10, 0, 8, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 2, 1, 0, 11, 7, 9, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 2, 1, 0, 12, 8, 0, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 2, 1, 7, 0, 0, 11, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 2, 1, 8, 0, 10, 12, null, sen_seq.nextval);
insert into seat values(seat_seq.nextval, 2, 1, 9, 0, 11, 0, null, sen_seq.nextval);

commit;