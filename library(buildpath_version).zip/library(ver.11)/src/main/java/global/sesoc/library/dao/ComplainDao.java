package global.sesoc.library.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;

import global.sesoc.library.dto.Complain;
import global.sesoc.library.dto.SeatPenalty;

public interface ComplainDao {
	public int report(Complain complain);
	
	public int getEveryComplaint(Map<String, Object> map);
	
	public List<Complain> selectAll(Map<String, Object> map, RowBounds rb);
	
	public Complain selectOne(int compnum);
	
	public int deleteComplaint(int compnum);
	
	public List<Complain> myReportList(String reguser);
	
	public List<Complain> compAgainstMe(String target);

	public List<Complain> penaltyCheck(String target);

	public List<Complain> penaltyCheck2(Map<String, Object> map);

	public String getIdBySeatnum(int seatnum);
	
	public int insertSP(SeatPenalty sp);
	
	public Complain getComp(int compnum);
	
	public int deleteSP(SeatPenalty sp);
	
	public SeatPenalty getSP(Map<String, Object> map);
	
	public int updateSPDate(SeatPenalty sp);
	
	public Complain compCheck(Complain comp);
}
