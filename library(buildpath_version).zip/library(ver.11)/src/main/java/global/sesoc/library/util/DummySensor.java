package global.sesoc.library.util;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import global.sesoc.library.dao.StudyDao;
import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;

public class DummySensor extends Thread {
	SerialPort serialPort = null;
	private String datas;
	private SqlSessionFactory factory = MybatisConfig.getSqlSessionFactory();
	
	public DummySensor() {
		// TODO Auto-generated constructor stub
	}
	
	public void setPort() {
		String portName = "";
		String[] portNames = SerialPortList.getPortNames();
		for(int i = 0; i < portNames.length; i++) {
			portName = portNames[i];
		}
		this.serialPort = new SerialPort(portName);
	}
	
	public void openMyPort() throws SerialPortException {
		serialPort.openPort();
		serialPort.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
				SerialPort.PARITY_NONE);
	}
	
	public void closeMyPort() {
		try {
			if (serialPort.isOpened())
				serialPort.closePort();
		} catch (SerialPortException e) {
			e.printStackTrace();
		} finally {
			if (!serialPort.isOpened())
				System.out.println("ByeBye");
		}
	}
	
	public void run() {
		SqlSession session = null;
		
		try {
			session = factory.openSession();
			StudyDao dao = session.getMapper(StudyDao.class);
			
			while (true) {
				datas = null;
				byte[] read = serialPort.readBytes();
				
				if (read != null && read.length > 0) {
					datas = new String(read);
				}
				
				if (datas != null && datas.trim().length() > 0) {
					System.out.println();
					System.out.print(datas);
					
					int data = Integer.parseInt(datas);
					
					if(data > 200) {
						continue;
					}
					
					dao.regBaseData(data);
					
					session.commit();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(serialPort.isOpened()) {
				try {
					serialPort.closePort();
				} catch (SerialPortException e) {
					e.printStackTrace();
				}
			}
			
			if(session != null) {
				session.commit();
				session.close();
			}
		}
	}
}
