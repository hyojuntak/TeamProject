package global.sesoc.library.dto;

public class Book {
	private int booknum;
	private String bookcode;
	private int bookid;
	private int status;	
	private String title;
	private String writer;
	private String publisher;
	private String pubdate;
	private String originfile;
	private String savedfile;
	
	public Book() {
		super();
	}

	public Book(int booknum, String bookcode, int bookid, int status, String title, String writer, String publisher,
			String pubdate, String originfile, String savedfile) {
		super();
		this.booknum = booknum;
		this.bookcode = bookcode;
		this.bookid = bookid;
		this.status = status;
		this.title = title;
		this.writer = writer;
		this.publisher = publisher;
		this.pubdate = pubdate;
		this.originfile = originfile;
		this.savedfile = savedfile;
	}

	public int getBooknum() {
		return booknum;
	}

	public void setBooknum(int booknum) {
		this.booknum = booknum;
	}

	public String getBookcode() {
		return bookcode;
	}

	public void setBookcode(String bookcode) {
		this.bookcode = bookcode;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getPubdate() {
		return pubdate;
	}

	public void setPubdate(String pubdate) {
		this.pubdate = pubdate;
	}

	public String getOriginfile() {
		return originfile;
	}

	public void setOriginfile(String originfile) {
		this.originfile = originfile;
	}

	public String getSavedfile() {
		return savedfile;
	}

	public void setSavedfile(String savedfile) {
		this.savedfile = savedfile;
	}

	@Override
	public String toString() {
		return "Book [booknum=" + booknum + ", bookcode=" + bookcode + ", bookid=" + bookid + ", status=" + status
				+ ", title=" + title + ", writer=" + writer + ", publisher=" + publisher + ", pubdate=" + pubdate
				+ ", originfile=" + originfile + ", savedfile=" + savedfile + "]";
	}
	
	

}
