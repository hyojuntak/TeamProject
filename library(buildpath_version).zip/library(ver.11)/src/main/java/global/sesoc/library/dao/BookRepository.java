package global.sesoc.library.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import global.sesoc.library.dto.Book;
import global.sesoc.library.dto.BookPenalty;
import global.sesoc.library.dto.BookView;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.MemberView;
import global.sesoc.library.dto.RentBook;

@Repository
public class BookRepository {
	
	@Autowired
	SqlSession session;

	public int insertBook(Book book) {
		
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.insertBook(book);
	
		return result;
	}

	public List<Book> selectAll() {
		
		BookDao dao = session.getMapper(BookDao.class);
		List<Book> bookList = dao.selectAll();

		return bookList;
	}

	public Book selectOne(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		Book book = dao.selectOne(booknum);
		
		return book;
	}

	public int deleteBook(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.deleteBook(booknum);
		
		return result;
	}

	public int updateBook(Book book) {
		// TODO Auto-generated method stub
		/*System.out.println("dao bookUpdate:"+book);*/
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.updateBook(book);
		
		return result;
	}

	public int recordCount() {
		// TODO Auto-generated method stub
		
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.recordCount();
		
		return result;
	}

	public List<Book> searchNum(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		List<Book> bookList = dao.searchNum(searchWord);

		return bookList;
	}

	public List<Book> searchTitle(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		List<Book> bookList = dao.searchTitle(searchWord);
		
		return bookList;
	}

	public List<Book> searchWriter(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		List<Book> bookList = dao.searchWriter(searchWord);
		
		return bookList;
	}

	public List<Book> searchPublisher(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao= session.getMapper(BookDao.class);
		List<Book> bookList = dao.searchPublisher(searchWord);
		
		return bookList;
	}

	public Book bookcodeCheck(String bookcode) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);

		Book book = dao.bookcodeCheck(bookcode);

		return book;
	}

	public int getTotalBook(String searchItem, String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);

		Map<String, String> map = new HashMap<>();
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);

		int result = dao.getTotalBook(map);
		


		
		return result;
		
	}

	public List<Book> searchBook(String searchItem, String searchWord, int startRecord, int count_PER_PAGE) {
		// TODO Auto-generated method stub
		RowBounds rb = new RowBounds(startRecord, count_PER_PAGE);
		
		BookDao dao = session.getMapper(BookDao.class);
		
		Map<String, Object> map = new HashMap<>();
		map.put("searchItem",searchItem);
		map.put("searchWord", searchWord);
		
		List<Book> list = dao.searchBook(map, rb);
		
		return list;
	}

	public Member searchUserId(String userid) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		Member member = dao.searchUserId(userid);
		
		return member;
	}

	public List<RentBook> searchRentInfo(String userid) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		List<RentBook> rentbook = dao.searchRentInfo(userid);
		
		
		return rentbook;
	}

	public Book searchBookInfo(String bookcode) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		Book book = dao.searchBookInfo(bookcode);
		
		return book;
	}

	public RentBook searchRentInfo2(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		RentBook rentbook = dao.searchRentInfo2(booknum);
		
		return rentbook;
	}

	public int rentBook(String userid, int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		Map<String, Object> map = new HashMap<>();
		map.put("userid", userid);
		map.put("booknum", booknum);
		
		int result = dao.rentBook(map);
		dao.updateStatus(booknum);
		dao.updateBookcount(userid);
		
				
		return result;
	}

	public BookPenalty bookPenalty(String userid) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		BookPenalty bookP = dao.bookPenalty(userid);
		
		return bookP;
	}

	public int rbCheck(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		int result = dao.rbCheck(booknum);
		
		return result;
	}
	
	public List<String> checkOver() {
		BookDao dao = session.getMapper(BookDao.class);
		List<String> list = dao.checkOver();
		return list;
	}
	
	public BookPenalty checkBookPenal(String userid) {
		BookDao dao = session.getMapper(BookDao.class);
		BookPenalty bp = dao.checkBookPenal(userid);
		return bp;
	}

	public int insertBP(String userid) {
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.insertBP(userid);
		return result;
	}
	
	public int updateBP(String userid) {
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.updateBP(userid);
		return result;
	}

	public List<Integer> checkOverBook() {
		BookDao dao = session.getMapper(BookDao.class);
		List<Integer> list = dao.checkOverBook();
		return list;
	}

	public int updateOverBook(int booknum) {
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.updateOverBook(booknum);
		return result;
	}

	public void returnBook(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		dao.returnBook(booknum);
		dao.returnRentBook(booknum);
	
		
	}

	public void returnBook2(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		dao.returnBook2(booknum);
		dao.returnRentBook2(booknum);
		
	}

	public List<RentBook> countCheck(String userid) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		List<RentBook> list = dao.countCheck(userid);
		
		return list;
	}

	public List<Book> allBookList() {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		List<Book> listBook = dao.allBookList();
		return listBook;
	}

	public List<RentBook> allRentList() {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		List<RentBook> listRent = dao.allRentList();
		return listRent;
	}
	
	public List<BookView> getBookView(Map<String, Object> map, int startRecord, int count_PER_PAGE) {
		
		RowBounds rb = new RowBounds(startRecord, count_PER_PAGE);
		
		BookDao dao = session.getMapper(BookDao.class);
		List<BookView> list = dao.getBookView(map,rb);
		return list;
	}

	public List<MemberView> getMemberView(Map<String, Object> map, int startRecord, int count_PER_PAGE) {
		// TODO Auto-generated method stub
		RowBounds rb = new RowBounds(startRecord, count_PER_PAGE);
		
		BookDao dao = session.getMapper(BookDao.class);
		List<MemberView> list = dao.getMemberView(map,rb);
		
		return list;
	}

	public BookView selectOne098(int booknum) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		BookView bookview = dao.selectOne098(booknum);
		return bookview;
	}
	
	public List<Book> getNewBook() {
		BookDao dao = session.getMapper(BookDao.class);
		List<Book> list = dao.getNewBook();
		return list;
	}
	
	public int getTotalMember1(Map<String, Object> map) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		int result = dao.getTotalMember1(map);
		
		return result;
	}

	public int getTotalBook1(Map<String, Object> map) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		
		int result = dao.getTotalBook1(map);
		
		return result;
	}

	public int searchCount(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.searchCount(searchWord);
		return result;
	}

	public int searchWriterCount(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.searchWriterCount(searchWord);
		return result;
	}

	public int searchBookcodeCount(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.searchBookcodeCount(searchWord);
		return result;
	}

	public int searchPublisherCount(String searchWord) {
		// TODO Auto-generated method stub
		BookDao dao = session.getMapper(BookDao.class);
		int result = dao.searchPublisherCount(searchWord);
		return result;
	}

	
}
