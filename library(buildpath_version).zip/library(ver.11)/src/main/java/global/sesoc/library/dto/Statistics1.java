package global.sesoc.library.dto;

public class Statistics1 {
	private Integer weekday;
	private Integer avgrs;
	private Integer avgwp;
	private Integer avgrsp;

	public Statistics1() {
		// TODO Auto-generated constructor stub
	}

	public Integer getWeekday() {
		return weekday;
	}

	public void setWeekday(Integer weekday) {
		this.weekday = weekday;
	}

	public Integer getAvgrs() {
		return avgrs;
	}

	public void setAvgrs(Integer avgrs) {
		this.avgrs = avgrs;
	}

	public Integer getAvgwp() {
		return avgwp;
	}

	public void setAvgwp(Integer avgwp) {
		this.avgwp = avgwp;
	}

	public Integer getAvgrsp() {
		return avgrsp;
	}

	public void setAvgrsp(Integer avgrsp) {
		this.avgrsp = avgrsp;
	}

	@Override
	public String toString() {
		return "Statistics1 [weekday=" + weekday + ", avgrs=" + avgrs + ", avgwp=" + avgwp + ", avgrsp=" + avgrsp + "]";
	}
}
