package global.sesoc.library.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import global.sesoc.library.dao.ComplainRepository;
import global.sesoc.library.dao.MemberRepository;
import global.sesoc.library.dto.Complain;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.RentBook;
import global.sesoc.library.dto.UserInfo;
import global.sesoc.library.util.FileService;

@Controller
public class MemberController {
	@Autowired
	MemberRepository repository;
	
	@Autowired
	ComplainRepository comprepository;
	

	final String uploadPath = "/LibraryResources";

	@RequestMapping(value = "joinForm")
	public String joinForm() {
		return "member/JoinForm";
	}

	// 회원가입 DB에 가서 데이터 입력
	@RequestMapping(value = "/Joinman", method = RequestMethod.POST)
	public String join(Member member, RedirectAttributes rattr, MultipartFile file) {
		// 파일업로드
		String savedfile = FileService.saveFile(file, uploadPath);
		String originfile = file.getOriginalFilename(); // db저장용

		member.setOriginfile(originfile);
		member.setSavedfile(savedfile);

		// insert 여부 확인(DB로부터 결과값받아서)
		int result = repository.insertJoin(member);

		if (result == 0) {
			rattr.addFlashAttribute("message", "会員加入に失敗しました。");
		}

		// 가입처리가 안될 시 에러화면으로 이동
		if (result != 0) {
			rattr.addFlashAttribute("message", "会員加入に成功しました。");
		}

		return "redirect:/";
	}

	// ID중복 확인 창 화면 요청
	@RequestMapping(value = "/idCheck", method = RequestMethod.GET)
	public String idCheck() {
		return "member/idCheckForm";
	}

	// ID중복확인 DB에서 아이디있는지 확인 후 가지고 옴
	@RequestMapping(value = "/idCheck", method = RequestMethod.POST)
	public @ResponseBody Member idCheck(Member member, Model model) {
		Member m = repository.selectOne(member);
		return m;
	}

	@RequestMapping(value = "login")
	public String login() {
		return "member/LoginForm";
	}

	@RequestMapping(value = "logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	//로그인(데이터넘기기)
	@RequestMapping(value = "login", method=RequestMethod.POST)
	public String login(Member member, HttpSession session, RedirectAttributes rattr) {
		Member m = repository.selectOne(member);
		if(m != null) {
			session.setAttribute("login", m);
		} else if(m == null) {
			rattr.addFlashAttribute("message", "ログインに失敗しました。");
		}
		return "redirect:/";
	}
	
	
	// =================================
	
	
	@RequestMapping(value = "myInfo")
	public String myInfo(HttpSession session) {
		return "member/myInfo";
	}
	
	@RequestMapping(value = "updateUserInfo", method=RequestMethod.GET)
	public String updateUserInfo() {
		return "member/updateUserInfo";
	}
	
	@RequestMapping(value = "updateUserInfo", method = RequestMethod.POST)
	public String updateUserInfo(Member member, HttpSession session, MultipartFile upload, RedirectAttributes rattr) {
		Member m = (Member) session.getAttribute("login");
		m.setPhone(member.getPhone());
		String originfile = upload.getOriginalFilename();
		
		if(originfile.length() > 0) {
			FileService.deleteFile(uploadPath + "/" + m.getSavedfile());
			String savedfile = FileService.saveFile(upload, uploadPath);
			
			m.setOriginfile(originfile);
			m.setSavedfile(savedfile);
		}
		
		int result = repository.updateUserInfo(m);
		
		if(result == 1) {
			rattr.addFlashAttribute("message", "会員情報が変更されました。");
		} else if(result == 0) {
			rattr.addFlashAttribute("message", "会員情報の変更に失敗しました。");
		}
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "updatePwd", method = RequestMethod.POST)
	public @ResponseBody int updatePwd(Member member, HttpSession session) {
		Member m = (Member) session.getAttribute("login");
		member.setUserid(m.getUserid());
		
		int result = repository.updatePwd(member);
		
		return result;
	}
	
	@RequestMapping(value = "deleteMember")
	public String deleteMember(HttpSession session, RedirectAttributes rattr) {
		Member m = (Member) session.getAttribute("login");
		int result = repository.deleteMember(m);
		
		if(result == 1) {
			rattr.addFlashAttribute("message", "会員脱退が完了されました。");
			session.invalidate();
			
		} else if(result == 0) {
			rattr.addFlashAttribute("message", "会員脱退に失敗しました。");
		}
		
		return "redirect:/";
	}
	
	// =======================
		// 민주
		// 관리자 userInfo ID이용자 조회
		@RequestMapping(value = "userInfo", method = RequestMethod.GET)
		public String userInfo() {
			return "userInfo";
		}

		@RequestMapping(value = "userInfo", method = RequestMethod.POST)
		public @ResponseBody UserInfo userInfo(@RequestBody Member member) {
			Member m = repository.selectOne(member);
			
			UserInfo user = new UserInfo();
			user.setMember(m);

			List<RentBook> rentbook = repository.selectRentbook(member.getUserid());
			user.setRentbook(rentbook);

			List<Complain> complain = repository.selectComplain(member.getUserid());
			user.setComplain(complain);
			return user;
		}
}
