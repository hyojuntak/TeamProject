package global.sesoc.library.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import global.sesoc.library.controller.StudyController;
import global.sesoc.library.dao.StudyDao;
import global.sesoc.library.dto.PortName;
import global.sesoc.library.dto.Reliability;
import global.sesoc.library.dto.Seat;
import global.sesoc.library.dto.WaitPaper;
import jssc.SerialPort;
import jssc.SerialPortException;

public class Sensor extends Thread {
	private static Map<String, SerialPort> portMap;
	private static SqlSessionFactory factory;
	private static double xbar;
	private static double sigma258;
	private boolean flag;
	private int seatNum;
	private int checkSec;
	private SerialPort port;
	private String datas;
	
	public Sensor(int seatNum) {
		this.seatNum = seatNum;
		flag = false;
		port = portMap.get("seat" + seatNum);
		checkSec = 0;
		datas = "";
	}
	
	public static void setSensor(List<PortName> portNames, Reliability rel) {
		portMap = new HashMap<String, SerialPort>();
		factory = MybatisConfig.getSqlSessionFactory();
		
		System.out.println("here is setSensor in Sensor class");
		System.out.println("portNames : " + portNames);
		System.out.println("portMap : " + portMap);
		
		xbar = rel.getXbar();
		sigma258 = rel.getSigma258();
		
		if(portNames.size() < 1) {
			return;
		}
				
		for(int i = 0; i < portNames.size(); i++) {
			String location = "seat" + portNames.get(i).getSeatnum();
			String portName = portNames.get(i).getPortname();
			portMap.put(location, new SerialPort(portName));
		}
	}
	
	public void openPort() {
		try {
			port.openPort();
			port.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
			
		} catch (SerialPortException e) {
			e.printStackTrace();
		}
	}
	
	public void closePort() {
		datas = "";
		checkSec = 0;
		
		try {
			if(port.isOpened()) {
				port.closePort();
			}
			
		} catch(SerialPortException e) {
			e.printStackTrace();
		}
	}
	
	public void turnOff() {
		flag = true;
	}
	
	public void turnOn() {
		flag = false;
	}

	@Override
	public void run() {
		SqlSession session = factory.openSession();
		StudyDao dao = session.getMapper(StudyDao.class);		

		if(!port.isOpened()) {
			openPort();
		}
		
		try {
			while(true) {
				datas = null;
				byte[] read = port.readBytes();
				Map<String, Object> map = new HashMap<String, Object>();
				
				if(read != null && read.length > 0) {
					datas = new String(read);
				}
				
				if(datas != null && datas.trim().length() > 0) {
					int data = Integer.parseInt(datas);
					
					if(data > 3000) {
						checkSec++;
						continue;
					}
					
					if(data > xbar + sigma258 || data < xbar - sigma258 && flag == false) {
						checkSec++;
						
						if(checkSec == 10) {
							map.put("seatnum", seatNum);
							map.put("status", -1);
							
							dao.updateSeatStatus(map);
							session.commit();
							
							dao.regAbstime(seatNum);
							session.commit();
						}
						
						if(checkSec == 20) {
							String userid = dao.getSeatUserid(seatNum);
							
							map.put("seatnum", seatNum);
							dao.returnSeat2(seatNum);
							session.commit();
							
							map.put("status", 1);
							dao.updateSeatStatus(map);
							session.commit();
							
							List<WaitPaper> unableWait = dao.getUnableWait(DateService.getFullToday());
							
							if(unableWait.size() > 0) {
								List<Seat> slist = dao.getAbleSeat();
								List<WaitPaper> wplist = dao.getAbleWait(DateService.getFullToday());
								
								if(slist.size() - wplist.size() > 0) {
									for(int i = 0; i < slist.size() - wplist.size(); i++) {
										
										if(unableWait.size() - i <= 0) {
											break;
										}
										
										dao.updateAbleWait(unableWait.get(i));
										session.commit();
									}
								}
							}
							
							StudyController.sensorMap.remove("seat" + seatNum);
							StudyController.sensorMap.put("seat" + seatNum, new Sensor(seatNum));
							
							String msg = "Your seat has been returned due to Over-1-Hour absence.";
							String rphone = dao.getSendPhone(userid);
							String sphone1 = "010";
							String sphone2 = "5205";
							String sphone3 = "0851";
							
							new Smssend(msg, rphone, sphone1, sphone2, sphone3);
							
							break;
						}
						
					} else if(data <= xbar + sigma258 || data >= xbar - sigma258 && flag == false) {
						map.put("seatnum", seatNum);
						map.put("status", 0);
						dao.updateSeatStatus(map);
						session.commit();
						
						checkSec = 0;
					}
					
					System.out.println("distance(cm) : " + data + " // absence time check(sec) : " + checkSec);
				}
				
				if(flag) {
					break;
				}
				
				Thread.sleep(200);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(port.isOpened()) {
				closePort();
			}
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("seatnum", seatNum);
			map.put("status", 1);
			
			dao.updateSeatStatus(map);
			session.commit();
			
			if(session != null) {
				session.commit();
				session.close();
			}
		}
	}

	public int getSeatNum() {
		return seatNum;
	}

	public void setSeatNum(int seatNum) {
		this.seatNum = seatNum;
	}

	public int getCheckSec() {
		return checkSec;
	}

	public void setCheckSec(int checkSec) {
		this.checkSec = checkSec;
	}

	public SerialPort getPort() {
		return port;
	}

	public void setPort(SerialPort port) {
		this.port = port;
	}

	public String getDatas() {
		return datas;
	}

	public void setDatas(String datas) {
		this.datas = datas;
	}
	
	public int getPortmapSize() {
		return portMap.size();
	}

	@Override
	public String toString() {
		return "Sensor [flag=" + flag + ", seatNum=" + seatNum + ", checkSec=" + checkSec + ", port=" + port
				+ ", datas=" + datas + "]";
	}
}
