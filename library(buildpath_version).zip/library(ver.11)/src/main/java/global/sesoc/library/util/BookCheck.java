package global.sesoc.library.util;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import global.sesoc.library.dao.BookDao;
import global.sesoc.library.dao.StudyDao;
import global.sesoc.library.dto.BookPenalty;

public class BookCheck extends Thread {
	private SqlSessionFactory factory;
	private boolean flag;
	
	public BookCheck() {
		factory = MybatisConfig.getSqlSessionFactory();
		flag = false;
	}
	
	public void turnOff() {
		flag = true;
	}
	
	@Override
	public void run() {
		SqlSession session = null;
		
		try {
			session = factory.openSession();
			BookDao dao = session.getMapper(BookDao.class);
			StudyDao sdao = session.getMapper(StudyDao.class);
			
			while(flag) {
				List<String> overMember = dao.checkOver();
				
				if(overMember.size() > 0) {
					String msg = "延滞中の書誌がございます。返納お願いいたします。";
					
					for(String userid : overMember) {
						BookPenalty bp = dao.checkBookPenal(userid);
						
						if(bp == null) {
							dao.insertBP(userid);
							session.commit();
							
							String rphone = sdao.getSendPhone(userid);
							String sphone1 = "010";
							String sphone2 = "5205";
							String sphone3 = "0851";
							
							new Smssend(msg, rphone, sphone1, sphone2, sphone3);
							
							break;
							
						} else if(bp != null) {
							dao.updateBP(userid);
							session.commit();
						}
					}
				}
				
				List<Integer> overBook = dao.checkOverBook();
				
				if(overBook.size() > 0) {
					for(Integer booknum : overBook) {
						dao.updateOverBook(booknum);
						session.commit();
					}
				}
				
				Thread.sleep(1000 * 60 * 60 * 24);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) {
				session.commit();
				session.close();
			}
		}
	}
}
