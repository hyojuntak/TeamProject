package global.sesoc.library.dto;

public class MemberView {
	private String userid;
	private String username;
	private String phone;
	private String birth;
	private int bookcount;
	private String enddate;
	
	public MemberView() {
		super();
	}

	public MemberView(String userid, String username, String phone, String birth, int bookcount, String enddate) {
		super();
		this.userid = userid;
		this.username = username;
		this.phone = phone;
		this.birth = birth;
		this.bookcount = bookcount;
		this.enddate = enddate;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public int getBookcount() {
		return bookcount;
	}

	public void setBookcount(int bookcount) {
		this.bookcount = bookcount;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "MemberView [userid=" + userid + ", username=" + username + ", phone=" + phone + ", birth=" + birth
				+ ", bookcount=" + bookcount + ", enddate=" + enddate + "]";
	}

		
}
