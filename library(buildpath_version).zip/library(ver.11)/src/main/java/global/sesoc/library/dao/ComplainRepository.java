package global.sesoc.library.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import global.sesoc.library.dto.Complain;
import global.sesoc.library.dto.SeatPenalty;

@Repository
public class ComplainRepository {
	@Autowired
	SqlSession session;
	
	public int report(Complain complain) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		int result = dao.report(complain);
		return result;
	}

	public int getEveryComplaint(String searchItem, String searchWord) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);
		
		int result = dao.getEveryComplaint(map);
		
		return result;
	}

	public List<Complain> selectAll(String searchItem, String searchWord, int startRecord, int COUNT_PER_PAGE) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		RowBounds rb = new RowBounds(startRecord, COUNT_PER_PAGE);
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startRecord", startRecord);
		map.put("countPerPage", COUNT_PER_PAGE);
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);

		List<Complain> list = dao.selectAll(map, rb);
		
		return list;
	}

	public Complain selectOne(int compnum) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		Complain complain = dao.selectOne(compnum);
		return complain;
	}

	public int deleteComplaint(int compnum) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		int result = dao.deleteComplaint(compnum);
		return result;
	}
	
	public List<Complain> myReportList(String reguser) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		List<Complain> list = dao.myReportList(reguser);
		return list;
	}
	
	public List<Complain> compAgainstMe(String target) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		List<Complain> list2 = dao.compAgainstMe(target);
		return list2;
	}

	public List<Complain> penaltyCheck(String target) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		List<Complain> list = dao.penaltyCheck(target);
		return list;
	}
	
	public List<Complain> penaltyCheck2(Map<String, Object> map) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		List<Complain> list2 = dao.penaltyCheck2(map);
		return list2;
	}

	public String getIdBySeatnum(int seatnum) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		String userid = dao.getIdBySeatnum(seatnum);
		return userid;
	}
	
	public int insertSP(SeatPenalty sp) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		int result = dao.insertSP(sp);
		return result;
	}
	
	public Complain getComp(int compnum) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		Complain comp = dao.getComp(compnum);
		return comp;
	}
	
	public int deleteSP(SeatPenalty sp) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		int result = dao.deleteSP(sp);
		return result;
	}
	
	public SeatPenalty getSP(Map<String, Object> map) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		SeatPenalty sp = dao.getSP(map);
		return sp;
	}
	
	public int updateSPDate(SeatPenalty sp) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		int result = dao.updateSPDate(sp);
		return result;
	}
	
	public Complain compCheck(Complain comp) {
		ComplainDao dao = session.getMapper(ComplainDao.class);
		Complain complain = dao.compCheck(comp);
		return complain;
	}
}
