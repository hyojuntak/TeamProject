package global.sesoc.library.dto;

public class PortName {
	private int seatnum;
	private String portname;

	public PortName() {
		// TODO Auto-generated constructor stub
	}
	
	public PortName(int seatnum, String portname) {
		super();
		this.seatnum = seatnum;
		this.portname = portname;
	}

	public int getSeatnum() {
		return seatnum;
	}

	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}

	public String getPortname() {
		return portname;
	}

	public void setPortname(String portname) {
		this.portname = portname;
	}

	@Override
	public String toString() {
		return "PortName [seatnum=" + seatnum + ", portname=" + portname + "]";
	}
}
