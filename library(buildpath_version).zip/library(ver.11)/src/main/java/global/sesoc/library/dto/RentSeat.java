package global.sesoc.library.dto;

public class RentSeat {
	private int rsnum;
	private String userid;
	private int seatnum;
	private int status;
	private String renttime;
	private String returntime;
	private int rentperiod;

	public RentSeat() {
		// TODO Auto-generated constructor stub
	}

	public int getRsnum() {
		return rsnum;
	}

	public void setRsnum(int rsnum) {
		this.rsnum = rsnum;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int getSeatnum() {
		return seatnum;
	}

	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getRenttime() {
		return renttime;
	}

	public void setRenttime(String renttime) {
		this.renttime = renttime;
	}

	public String getReturntime() {
		return returntime;
	}

	public void setReturntime(String returntime) {
		this.returntime = returntime;
	}

	public int getRentperiod() {
		return rentperiod;
	}

	public void setRentperiod(int rentperiod) {
		this.rentperiod = rentperiod;
	}

	@Override
	public String toString() {
		return "RentSeat [rsnum=" + rsnum + ", userid=" + userid + ", seatnum=" + seatnum + ", status=" + status
				+ ", renttime=" + renttime + ", returntime=" + returntime + ", rentperiod=" + rentperiod + "]";
	}
}
