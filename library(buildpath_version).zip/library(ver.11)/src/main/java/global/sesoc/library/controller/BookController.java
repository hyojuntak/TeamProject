package global.sesoc.library.controller;

import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import global.sesoc.library.dao.BookRepository;
import global.sesoc.library.dto.Book;
import global.sesoc.library.dto.BookPenalty;
import global.sesoc.library.dto.BookView;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.MemberView;
import global.sesoc.library.dto.RentBook;
import global.sesoc.library.util.FileService;
import global.sesoc.library.util.PageNavigator2;

@Controller
public class BookController {
	@Autowired
	BookRepository repository;

	final String uploadPath = "/LibraryResources";
	
	@RequestMapping(value = "searchBookForm", method = RequestMethod.GET)
	public String searchBookForm() {
		return "book/searchBook";
	}


	@RequestMapping(value = "searchBook", method = RequestMethod.GET)
	public String searchBook(Model model, @RequestParam(value = "searchItem", defaultValue = "title") String searchItem,
			@RequestParam(value = "searchWord", defaultValue = "") String searchWord,
			@RequestParam(value = "currentPage", defaultValue = "1") int currentPage) {

		int totalRecordCount = repository.getTotalBook(searchItem, searchWord);

		PageNavigator2 navi = new PageNavigator2(currentPage, totalRecordCount);

		List<Book> list = repository.searchBook(searchItem, searchWord, navi.getStartRecord(),
				navi.getCOUNT_PER_PAGE());

		model.addAttribute("list", list);
		model.addAttribute("totalBook", totalRecordCount);
		model.addAttribute("searchItem", searchItem);
		model.addAttribute("searchWord", searchWord);
		model.addAttribute("navi", navi);
		model.addAttribute("currentPage", currentPage);
		
		if(list.size() < 1) {
			String msg = "\"" + searchWord + "\" に該当する検索結果がございません。";
			model.addAttribute("msg", msg);
		} else if(list.size() > 0) {
			String msg = "\"" + searchWord + "\" に該当する検索結果は(総 " + totalRecordCount + "件) です。";
			model.addAttribute("msg", msg);
		}
		

		return "book/searchBook";
	}

	@RequestMapping(value = "bookDetail")
	public String bookDetail(int booknum, Model model) {
		Book book = repository.selectOne(booknum);
		
		BookView bookview = repository.selectOne098(booknum);
		
		model.addAttribute("book", book);
		model.addAttribute("bookview", bookview);

		return "book/bookDetail";
	}

	@RequestMapping(value = "adminBook")
	public String adminBook() {
		return "book/adminBook";
	}

	@RequestMapping(value = "/insertBook", method = RequestMethod.POST)
	public String insertBook(Book book, MultipartFile upload) {
		String savedfile = FileService.saveFile(upload, uploadPath);
		String originfile = upload.getOriginalFilename();

		book.setOriginfile(originfile);
		book.setSavedfile(savedfile);
		repository.insertBook(book);

		return "redirect:/adminBook";
	}

	@RequestMapping(value = "bookAll", method = RequestMethod.POST)
	public @ResponseBody List<Book> bookAll() {
		List<Book> bookList = repository.selectAll();

		return bookList;
	}

	@RequestMapping(value = "selectOne", method = RequestMethod.POST)
	public @ResponseBody Book selectOne(int booknum) {
		Book book = repository.selectOne(booknum);

		String fullPath = null;
		if (book.getOriginfile() != null) {
			fullPath = uploadPath + "/" + book.getSavedfile();
		}
		book.setSavedfile(fullPath);

		return book;
	}

	@RequestMapping(value = "/download2", method = RequestMethod.GET)
	public String download(int booknum, HttpServletResponse response) {

		Book book = repository.selectOne(booknum);
		String originfile = book.getOriginfile();
		String savedfile = book.getSavedfile();
		String fullPath = uploadPath + "/" + savedfile;

		try {
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(originfile, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		FileInputStream fin = null;
		ServletOutputStream fileout = null;

		try {
			fin = new FileInputStream(fullPath);
			fileout = response.getOutputStream();

			FileCopyUtils.copy(fin, fileout);

			fin.close();
			fileout.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "deleteBook", method = RequestMethod.POST)
	public @ResponseBody Integer deleteBook(int booknum) {
		Book book = repository.selectOne(booknum);

		if (book.getOriginfile() != null) {
			String fullPath = uploadPath + "/" + book.getSavedfile();
			FileService.deleteFile(fullPath);
		}

		int result = repository.deleteBook(booknum);

		return result;
	}

	@RequestMapping(value = "/updateBook", method = RequestMethod.POST)
	public String updateBook(Book book, MultipartFile upload) {
		Book b = repository.selectOne(book.getBooknum());
		
		if(upload.getOriginalFilename().equals("")) {
			book.setOriginfile(b.getOriginfile());
			book.setSavedfile(b.getSavedfile());
			
		} else if(!upload.getOriginalFilename().equals("")) {
			FileService.deleteFile(uploadPath + "/" + b.getSavedfile());
			String originfile = upload.getOriginalFilename();
			String savedfile = FileService.saveFile(upload, uploadPath);
			
			book.setOriginfile(originfile);
			book.setSavedfile(savedfile);
		}
		
		repository.updateBook(book);

		return "redirect:/adminBook";
	}

	@RequestMapping(value = "deleteFile", method = RequestMethod.POST)
	public @ResponseBody String deleteFile(int booknum) {
		Book book = repository.selectOne(booknum);

		String fullPath = uploadPath + "/" + book.getSavedfile();
		FileService.deleteFile(fullPath);
		book.setOriginfile("");
		book.setSavedfile("");
		repository.updateBook(book);

		return null;
	}

	@RequestMapping(value = "recordCount", method = RequestMethod.POST)
	public @ResponseBody Integer recordCount() {
		int result = repository.recordCount();
		return result;
	}
	
	@RequestMapping(value = "searchCount", method = RequestMethod.POST)
	public @ResponseBody Integer searchTitleCount(String searchWord) {
		int result = repository.searchCount(searchWord);
		return result;
	}
	
	@RequestMapping(value = "searchWriterCount", method = RequestMethod.POST)
	public @ResponseBody Integer searchWriterCount(String searchWord) {
		int result = repository.searchWriterCount(searchWord);
		return result;
	}
	
	@RequestMapping(value = "searchBookcodeCount", method = RequestMethod.POST)
	public @ResponseBody Integer searchBookcodeCount(String searchWord) {
		int result = repository.searchBookcodeCount(searchWord);
		return result;
	}
	
	@RequestMapping(value = "searchPublisherCount", method = RequestMethod.POST)
	public @ResponseBody Integer searchPublisherCount(String searchWord) {
		int result = repository.searchPublisherCount(searchWord);
		return result;
	}


	@RequestMapping(value = "searchNum", method = RequestMethod.POST)
	public @ResponseBody List<Book> searchWord(String searchWord) {
		List<Book> bookList = repository.searchNum(searchWord);
		return bookList;
	}

	@RequestMapping(value = "searchTitle", method = RequestMethod.POST)
	public @ResponseBody List<Book> searchWord2(String searchWord) {
		List<Book> bookList = repository.searchTitle(searchWord);

		return bookList;

	}

	@RequestMapping(value = "searchWriter", method = RequestMethod.POST)
	public @ResponseBody List<Book> searchWord3(String searchWord) {
		List<Book> bookList = repository.searchWriter(searchWord);

		return bookList;

	}

	@RequestMapping(value = "searchPublisher", method = RequestMethod.POST)
	public @ResponseBody List<Book> searchWord4(String searchWord) {
		List<Book> bookList = repository.searchPublisher(searchWord);

		return bookList;

	}

	@RequestMapping(value = "bookcodeCheck", method = RequestMethod.POST)
	public @ResponseBody boolean bookcodeCheck(String bookcode) {
		Book book = repository.bookcodeCheck(bookcode);

		if (book != null) {
			return false;
		}
		return true;
	}

	@RequestMapping(value = "rentBook")
	public String rentBook() {
		return "book/rentBook";
	}

	@RequestMapping(value = "searchId-sdf", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> searchUserId(String userid) {
		
		Member member = repository.searchUserId(userid);
		List<RentBook> rentbook = repository.searchRentInfo(userid);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("m", member);
		map.put("rb", rentbook);

		return map;

	}

	@RequestMapping(value = "serarchBook-sdf", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> searchBookAndRentInfo(String bookcode) {

		Book book = repository.searchBookInfo(bookcode);

		RentBook rentbook = repository.searchRentInfo2(book.getBooknum());

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("b", book);
		map.put("rb2", rentbook);

		return map;
	}

	@RequestMapping(value = "bookPenaltyCheck", method = RequestMethod.POST)
	public @ResponseBody boolean bookPenaltyCheck(String userid) {
		BookPenalty bookP = repository.bookPenalty(userid);
		if (bookP == null) {
			return true;
		}

		return false;
	}

	@RequestMapping(value = "rbCheck", method = RequestMethod.POST)
	public @ResponseBody boolean rbCheck(int booknum) {
		int result = repository.rbCheck(booknum);

		if (result == 0 || result == -1) {
			return false;
		}
		return true;
	}

	@RequestMapping(value = "rentBook2", method = RequestMethod.GET)
	public String rentBook(String userid, int booknum) {

		repository.rentBook(userid, booknum);

		return "redirect:rentBook";

	}
	
	@RequestMapping(value = "returnBook2", method = RequestMethod.GET)
	public String returnBook(int booknum) {

		int result = repository.rbCheck(booknum);
		if (result == 0) {
			repository.returnBook(booknum);
		} else if (result == -1) {
			repository.returnBook2(booknum);
		}

		return "redirect:rentBook";
	}

	@RequestMapping(value = "countCheck", method = RequestMethod.POST)
	public @ResponseBody boolean countCheck(String userid) {
		List<RentBook> list = repository.countCheck(userid);
		if (list.size() > 6) {
			return false;
		}

		return true;

	}

	@RequestMapping(value = "allInfoBookData", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> allInfoBookData(
			@RequestParam(value = "searchItem", defaultValue = "bookcode") String searchItem,
			@RequestParam(value = "searchWord", defaultValue = "") String searchWord,
			@RequestParam(value="page1", defaultValue= "1") int currentPage){

		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);
		
		int totalRecordCount = repository.getTotalBook1(map);
		
		PageNavigator2 navi = new PageNavigator2(currentPage, totalRecordCount);

		List<BookView> list = repository.getBookView(map, navi.getStartRecord(), navi.getCOUNT_PER_PAGE());

		for (int i = 0; list.size() > i; i++) {

			if (list.get(i).getStatus() == 0 || list.get(i).getStatus() == -1) {
				list.get(i).setStatusView("✖");
			} else if (list.get(i).getStatus() == 1) {
				list.get(i).setStatusView("〇");
			}
		}

		map.put("bvlist", list);
		map.put("navi", navi);
		
		return map;
	}

	@RequestMapping(value = "allInfoMemberData", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> allInfoMemberData(
			@RequestParam(value = "searchItem2", defaultValue = "userid") String searchItem2,
			@RequestParam(value = "searchWord2", defaultValue = "") String searchWord2,
			@RequestParam(value = "page", defaultValue = "1") int currentPage){
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("searchItem2", searchItem2);
		map.put("searchWord2", searchWord2);
		
		int totalRecordCount = repository.getTotalMember1(map);
		PageNavigator2 navi = new PageNavigator2(currentPage, totalRecordCount);
		
	    List<MemberView> list = repository.getMemberView(map, navi.getStartRecord(), navi.getCOUNT_PER_PAGE());
		
	    map.put("mvlist", list);
	    map.put("navi", navi);
	    
	    return map;
	}
}
