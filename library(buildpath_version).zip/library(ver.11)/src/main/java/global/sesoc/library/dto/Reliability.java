package global.sesoc.library.dto;

public class Reliability {
	private double xbar;
	private double sigma258;

	public Reliability() {
		// TODO Auto-generated constructor stub
	}

	public double getXbar() {
		return xbar;
	}

	public void setXbar(double xbar) {
		this.xbar = xbar;
	}

	public double getSigma258() {
		return sigma258;
	}

	public void setSigma258(double sigma258) {
		this.sigma258 = sigma258;
	}

	@Override
	public String toString() {
		return "Reliability [xbar=" + xbar + ", sigma258=" + sigma258 + "]";
	}
}
