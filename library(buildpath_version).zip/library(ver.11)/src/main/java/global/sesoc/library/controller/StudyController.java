package global.sesoc.library.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import global.sesoc.library.dao.StudyRepository;
import global.sesoc.library.dto.Desk;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.PortName;
import global.sesoc.library.dto.RentSeat;
import global.sesoc.library.dto.Seat;
import global.sesoc.library.dto.SeatPenalty;
import global.sesoc.library.dto.SeatUser;
import global.sesoc.library.dto.Statistics1;
import global.sesoc.library.dto.Statistics2;
import global.sesoc.library.dto.SubUserInfo;
import global.sesoc.library.dto.WaitPaper;
import global.sesoc.library.util.DateService;
import global.sesoc.library.util.DummySensor;
import global.sesoc.library.util.Sensor;
import global.sesoc.library.util.WaitChecker;
import jssc.SerialPortException;

@Controller
public class StudyController {
	@Autowired
	StudyRepository repository;
	
	public static Map<String, Sensor> sensorMap;
	public static WaitChecker waitChecker;
	final String uploadPath = "/LibraryResources";
	private DummySensor dummySensor;
	
	@RequestMapping(value = "studyMenu")
	public String studyMenu() {
		return "study/studyMenu";
	}
	
	@RequestMapping(value = "studyInfo")
	public String studyInfo() {
		return "study/studyInfo";
	}
	
	@RequestMapping(value = "getSeat", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> getSeat(int location) {
		List<Desk> dlist = repository.getAllDesk(location);
		List<Seat> slist = repository.getAllSeat(location);
		
		List<WaitPaper> allPaper = repository.getAllWait(DateService.getFullToday());
		List<WaitPaper> ablePaper = repository.getAbleWait(DateService.getFullToday());
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dlist", dlist);
		map.put("slist", slist);
		map.put("wait", allPaper.size());
		
		if(ablePaper.size() != 0) {
			map.put("call", ablePaper.get(ablePaper.size() - 1).getWaitnum());
		} else {
			map.put("call", 0);
		}
		
		return map;
	}
	
	@RequestMapping(value = "studyIssue")
	public String studyIssue() {
		List<WaitPaper> wait = repository.getAllWait(DateService.getFullToday());
		List<Seat> ableSeat = repository.getAbleSeat();
		
		if(ableSeat.size() <= wait.size() || ableSeat.size() == 0) {
			return "study/waitIssue";
		}
		
		return "study/studyIssue";
	}
	
	@RequestMapping(value = "subUserInfo")
	public String subUserInfo(int seatnum, Model model) {
		SubUserInfo sui = repository.getSubUserInfo(seatnum);
		model.addAttribute("subUserInfo", sui);
		return "study/subUserInfo";
	}
	
	/**
	 * @param seatnum
	 * @param session
	 * @param rattr
	 * @return
	 */
	@SuppressWarnings("unused")
	@RequestMapping(value = "issue")
	public String issue(int seatnum, HttpSession session, RedirectAttributes rattr) {
		Member member = (Member) session.getAttribute("login");
		RentSeat usingSeat = repository.getUsingSeat(member.getUserid());
		
		String userid = member.getUserid();
		SeatPenalty sp0 = repository.getSP0(userid);
		List<SeatPenalty> sp1List = repository.getSP1(userid);
		
		int result = 0;
		
		if(sp0 == null) {
			if(member != null) {
				if(usingSeat == null) {
					if(sp1List.size() < 1) {
						RentSeat rs = new RentSeat();
						rs.setUserid(member.getUserid());
						rs.setSeatnum(seatnum);
						result = repository.insertRentSeat(rs);
						
						WaitPaper wp = repository.getAbleWaitById(member.getUserid());
						
						if(wp != null) {
							repository.useWait(wp);
						}
						
						if(result == 1) {
							Map<String, Object> map = new HashMap<String, Object>();
							map.put("seatnum", seatnum);
							map.put("status", 0);
							
							repository.updateSeatStatus(map);
							
							PortName portName = repository.getPortName(seatnum);
							
							if(portName != null) {
								System.out.println("here is thread.start");
								sensorMap.get("seat" + seatnum).start();
							}

							rattr.addFlashAttribute("message", "座席発給かできました。 座席番号 : " + seatnum);
							
						} else if(result == 0) {
							rattr.addFlashAttribute("message", "座席発給に失敗しました。");
						}
						
					} else if(sp1List.size() >= 1) {
						List<String> partner = new ArrayList<String>();
						SeatUser su = repository.checkPartner(seatnum);
						int flag = 0;
						String tempUser = "";
						
						for(int i = 0; i < sp1List.size(); i++) {
							SeatPenalty sp1 = sp1List.get(i);
							
							if(userid.equals(sp1.getUserid())) {
								partner.add(sp1.getUserid2());
							} else if(userid.equals(sp1.getUserid2())) {
								partner.add(sp1.getUserid());
							}
						}
						
						for(int i = 0; i < partner.size(); i++) {
							if(partner.get(i).equals(su.getUpsid())) {
								flag++;
								tempUser = partner.get(i);
								break;
							}
							
							if(partner.get(i).equals(su.getDownsid())) {
								flag++;
								tempUser = partner.get(i);
								break;
							}
							
							if(partner.get(i).equals(su.getLeftsid())) {
								flag++;
								tempUser = partner.get(i);
								break;
							}
							
							if(partner.get(i).equals(su.getRightsid())) {
								flag++;
								tempUser = partner.get(i);
								break;
							}
						}
						
						if(flag == 0) {
							RentSeat rs = new RentSeat();
							rs.setUserid(member.getUserid());
							rs.setSeatnum(seatnum);
							result = repository.insertRentSeat(rs);
							
							if(result == 1) {
								Map<String, Object> map = new HashMap<String, Object>();
								map.put("seatnum", seatnum);
								map.put("status", 0);
								
								repository.updateSeatStatus(map);
								
								PortName portName = repository.getPortName(seatnum);
								
								if(portName != null) {
									sensorMap.get("seat" + seatnum).start();
								}

								rattr.addFlashAttribute("message", "座席発給かできました。 座席番号 : " + seatnum);
								
							} else if(result == 0) {
								rattr.addFlashAttribute("message", "座席発給に失敗しました。");
							}
							
						} else if(flag > 0) {
							rattr.addFlashAttribute("message", tempUser + "様の隣席には予約できません。");
						}
					}
					
				} else if(usingSeat != null) {
					rattr.addFlashAttribute("message", "すでに利用している座席がございます。");
				}
				
			} else if(member == null) {
				rattr.addFlashAttribute("message", "ログインしてから利用してください。");
			}
			
		} else if(sp0 != null) {
			rattr.addFlashAttribute("message", "人からのコンプレインのため、閲覧室の利用が制限されました。");
		}
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "getLogin", method = RequestMethod.POST)
	public @ResponseBody Member getUsertype(HttpSession session) {
		Member user = (Member) session.getAttribute("login");
		return user;
	}
	
	@RequestMapping(value = "download")
	public String download(String savedfile, String originfile, HttpServletResponse response) {
		if(savedfile.equals("") || savedfile == null) {
			return null;
		}
		
		String fullPath = uploadPath + "/" + savedfile;
		String originFile = originfile;
		
		// Header 설정
		try {
			response.setHeader("Content-Disposition", " attachment;filename=" + URLEncoder.encode(originFile, "UTF-8"));
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		FileInputStream filein = null;
		ServletOutputStream fileout = null;
		
		try {
			filein = new FileInputStream(fullPath);
			fileout = response.getOutputStream();
			
			// 실제 파일을 복사하는 명령
			FileCopyUtils.copy(filein, fileout);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(filein != null)
				try {
					filein.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			if(fileout != null)
				try {
					fileout.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		
		return null;
	}
	
	@RequestMapping(value = "seatPaper")
	public String seatPaper(HttpSession session, Model model) {
		Member member = (Member) session.getAttribute("login");
		RentSeat rs = repository.getRentPaper(member.getUserid());
		
		if(rs == null) {
			WaitPaper wp = repository.getWaitPaper(member.getUserid());
			
			if(wp == null) {
				model.addAttribute("flag", 0);
				
			} else if(wp != null) {
				WaitPaper waitInfo = repository.getWaitInfo(member.getUserid());
				model.addAttribute("flag", 2);
				model.addAttribute("waitInfo", waitInfo);
			}
			
		} else if(rs != null) {
			model.addAttribute("flag", 1);
			model.addAttribute("seatPaper", rs);
		}
		return "study/seatPaper";
	}
	
	@RequestMapping(value = "waitIssue")
	public String waitIssue(HttpSession session, RedirectAttributes rattr) {
		Member member = (Member) session.getAttribute("login");
		RentSeat usingSeat = repository.getUsingSeat(member.getUserid());
		WaitPaper waitpaper = new WaitPaper();
		int result = 0;
		
		if(usingSeat == null) {
			WaitPaper tempwp = repository.getWaitPaper(member.getUserid());
			
			if(tempwp == null) {
				List<WaitPaper> wp = repository.getAllPaper();
				
				if(wp.size() == 0) {
					waitpaper.setWaitnum(1);
					waitpaper.setUserid(member.getUserid());
					result = repository.insertWait(waitpaper);
					
					if(result == 1) {
						rattr.addFlashAttribute("message", "整理券発給ができました。 順番 : " + waitpaper.getWaitnum());
					} else if(result == 0) {
						rattr.addFlashAttribute("message", "整理券発給に失敗しました。");
					}
					
				} else if(wp.size() != 0) {
					waitpaper.setWaitnum(wp.get(0).getWaitnum() + 1);
					waitpaper.setUserid(member.getUserid());
					result = repository.insertWait(waitpaper);
					
					if(result == 1) {
						rattr.addFlashAttribute("message", "整理券発給ができました。 順番 : " + waitpaper.getWaitnum());
					} else if(result == 0) {
						rattr.addFlashAttribute("message", "整理券発給に失敗しました。");
					}
				}
				
			} else if(tempwp != null) {
				rattr.addFlashAttribute("message", "すでに発給された整理券がございます。");
			}
			
		} else if(usingSeat != null) {
			rattr.addFlashAttribute("message", "すでに利用している座席がございます。");
		}
		
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "returnSeat")
	public String returnSeat(HttpSession session, int seatnum, RedirectAttributes rattr) {
		Member member = (Member) session.getAttribute("login");
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userid", member.getUserid());
		map.put("seatnum", seatnum);
		map.put("status", 1);
		
		int result = repository.returnSeat(map);

		if(result == 1) {
			System.out.println("here is thread turnoff");
			try {
				PortName portName = repository.getPortName(seatnum);
				
				if(portName != null) {
					sensorMap.get("seat" + seatnum).turnOff();
					sensorMap.remove("seat" + seatnum);
					sensorMap.put("seat" + seatnum, new Sensor(seatnum));
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			repository.updateSeatStatus(map);
			
			rattr.addFlashAttribute("message", "座席の返納が完了されました。");
			
			// 대기표 존재 시...
			List<WaitPaper> unableWait = repository.getUnableWait(DateService.getFullToday());
			
			if(unableWait.size() > 0) {
				List<Seat> slist = repository.getAbleSeat();
				List<WaitPaper> wplist = repository.getAbleWait(DateService.getFullToday());
				
				if(slist.size() - wplist.size() > 0) {
					for(int i = 0; i < slist.size() - wplist.size(); i++) {
						
						if(unableWait.size() - i <= 0) {
							break;
						}
						
						repository.updateAbleWait(unableWait.get(i));
					}
				}
			}
			
		} else if(result == 0) {
			rattr.addFlashAttribute("message", "座席の返納に失敗しました。");
		}
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "paperCheck", method = RequestMethod.POST)
	public @ResponseBody WaitPaper paperCheck(@RequestBody Member member) {
		WaitPaper wp = repository.getWaitPaper(member.getUserid());
		return wp;
	}
	
	@RequestMapping(value = "useWait", method = RequestMethod.POST)
	public @ResponseBody int useWait(@RequestBody Member member) {
		WaitPaper wp = repository.getAbleWaitById(member.getUserid());
		int result = repository.useWait(wp);
		return result;
	}
	
	@RequestMapping(value = "studySta")
	public String studySta() {
		return "study/studySta";
	}
	
	@RequestMapping(value = "getSta1", method = RequestMethod.POST)
	public @ResponseBody List<Statistics1> getSta1() {
		List<Statistics1> list = repository.getSta1();
		if(list.size() < 1) {
			Statistics1 st = new Statistics1();
			st.setWeekday(1);
			st.setAvgrs(0);
			st.setAvgrsp(0);
			st.setAvgwp(0);
			list.add(st);
		}
		return list;
	}
	
	@RequestMapping(value = "getSta2", method = RequestMethod.POST)
	public @ResponseBody List<Statistics2> getSta2(int weekday) {
		List<Statistics2> list = new ArrayList<Statistics2>();
		Statistics2 sta2 = new Statistics2();
		sta2.setWeekday(weekday);
		
		for(int checktime = 9; checktime < 24; checktime++) {
			for(int i = 0; i < 2; i++) {
				if(i == 0) {
					sta2.setChecktime(Integer.parseInt(checktime + "00"));
					Statistics2 tempSta2 = repository.getSta2(sta2);
					
					if(tempSta2 == null) {
						list.add(new Statistics2(sta2.getWeekday(), sta2.getChecktime(), 0, 0));
						continue;
						
					} else if(tempSta2 != null) {
						tempSta2.setChecktime(sta2.getChecktime());
						list.add(tempSta2);
						continue;
					}
					
				} else if(i == 1) {
					sta2.setChecktime(Integer.parseInt(checktime + "30"));
					Statistics2 tempSta2 = repository.getSta2(sta2);

					if(tempSta2 == null) {
						list.add(new Statistics2(sta2.getWeekday(), sta2.getChecktime(), 0, 0));
						continue;
						
					} else if(tempSta2 != null) {
						tempSta2.setChecktime(sta2.getChecktime());
						list.add(tempSta2);
						continue;
					}
				}
			}
		}
		return list;
	}
	
	@RequestMapping(value = "baseData")
	public String baseData() {
		return "study/baseData";
	}
	
	@RequestMapping(value = "startBase", method = RequestMethod.POST)
	public @ResponseBody void startBase() {
		dummySensor = new DummySensor();
		dummySensor.setPort();
		try {
			dummySensor.openMyPort();
		} catch (SerialPortException e) {
			e.printStackTrace();
		}
		dummySensor.start();
	}
	
	@RequestMapping(value = "stopBase", method = RequestMethod.POST)
	public @ResponseBody void stopBase() {
		dummySensor.closeMyPort();
		dummySensor.interrupt();
	}
}
