package global.sesoc.library.dto;

public class SeatPenalty {
	private int spnum;
	private String userid;
	private String userid2;
	private int penaltytype;
	private String startdate;
	private String enddate;

	public SeatPenalty() {
		// TODO Auto-generated constructor stub
	}

	public int getSpnum() {
		return spnum;
	}

	public void setSpnum(int spnum) {
		this.spnum = spnum;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUserid2() {
		return userid2;
	}

	public void setUserid2(String userid2) {
		this.userid2 = userid2;
	}

	public int getPenaltytype() {
		return penaltytype;
	}

	public void setPenaltytype(int penaltytype) {
		this.penaltytype = penaltytype;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "SeatPenalty [spnum=" + spnum + ", userid=" + userid + ", userid2=" + userid2 + ", penaltytype="
				+ penaltytype + ", startdate=" + startdate + ", enddate=" + enddate + "]";
	}
}
