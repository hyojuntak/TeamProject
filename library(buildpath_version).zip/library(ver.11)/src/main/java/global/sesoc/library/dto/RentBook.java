package global.sesoc.library.dto;

public class RentBook {
	private int rbnum;
	private String bookcode;
	private String userid;
	private String booknum;
	private String title;
	private int status;
	private String rentdate;
	private String enddate;
	private String returndate;
	private int rentperiod;
	
	public RentBook() {
		// TODO Auto-generated constructor stub
	}

	public int getRbnum() {
		return rbnum;
	}

	public void setRbnum(int rbnum) {
		this.rbnum = rbnum;
	}

	public String getBookcode() {
		return bookcode;
	}

	public void setBookcode(String bookcode) {
		this.bookcode = bookcode;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getBooknum() {
		return booknum;
	}

	public void setBooknum(String booknum) {
		this.booknum = booknum;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getRentdate() {
		return rentdate;
	}

	public void setRentdate(String rentdate) {
		this.rentdate = rentdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getReturndate() {
		return returndate;
	}

	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}

	public int getRentperiod() {
		return rentperiod;
	}

	public void setRentperiod(int rentperiod) {
		this.rentperiod = rentperiod;
	}

	@Override
	public String toString() {
		return "RentBook [rbnum=" + rbnum + ", bookcode=" + bookcode + ", userid=" + userid + ", booknum=" + booknum
				+ ", title=" + title + ", status=" + status + ", rentdate=" + rentdate + ", enddate=" + enddate
				+ ", returndate=" + returndate + ", rentperiod=" + rentperiod + "]";
	}

	
	
}
