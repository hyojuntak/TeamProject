package global.sesoc.library;

import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import global.sesoc.library.controller.StudyController;
import global.sesoc.library.dao.StudyDao;
import global.sesoc.library.dto.PortName;
import global.sesoc.library.dto.Reliability;
import global.sesoc.library.util.BookCheck;
import global.sesoc.library.util.MybatisConfig;
import global.sesoc.library.util.Sensor;
import global.sesoc.library.util.WaitChecker;
import jssc.SerialPortList;

public class MyServletContextListener implements ServletContextListener {
	private WaitChecker waitChecker;
	private BookCheck bookChecker;
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		SqlSession session = null;
		
		try {
			SqlSessionFactory factory = MybatisConfig.getSqlSessionFactory();
			session = factory.openSession();
			StudyDao dao = session.getMapper(StudyDao.class);
			
			List<PortName> portNames = dao.getPortNames();
			Reliability rel = dao.getReliability();
			
			if(rel == null) {
				rel = new Reliability();
				rel.setXbar(40);
				rel.setSigma258(80);
			}
			
			if(portNames.size() == 0) {
				String[] portNames2 = SerialPortList.getPortNames();
				
				for(int i = 0; i < portNames2.length; i++) {
					dao.insertPortNames(new PortName(i + 1, portNames2[i]));
					session.commit();
				}
				
				portNames = dao.getPortNames();
			}
			
			Sensor.setSensor(portNames, rel);
			
			StudyController.sensorMap = new HashMap<String, Sensor>();

			for (int i = 0; i < portNames.size(); i++) {
				int seatNum = portNames.get(i).getSeatnum();
				StudyController.sensorMap.put("seat" + seatNum, new Sensor(seatNum));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			
		} finally {
			if(session != null) {
				session.commit();
				session.close();
			}
		}
		
		waitChecker = new WaitChecker();
		waitChecker.start();
		
		bookChecker = new BookCheck();
		bookChecker.start();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		bookChecker.turnOff();
		waitChecker.turnOff();
		
		if(StudyController.sensorMap != null) {
			int size = StudyController.sensorMap.get("seat1").getPortmapSize();
			
			for (int i = 0; i < size; i++) {
				Sensor temp = StudyController.sensorMap.get("seat" + (i + 1));
				temp.turnOff();
				temp.closePort();
			}
		}
	}

	public MyServletContextListener() {
		// TODO Auto-generated constructor stub
	}
}
