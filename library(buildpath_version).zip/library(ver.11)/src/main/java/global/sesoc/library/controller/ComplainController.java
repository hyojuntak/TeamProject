package global.sesoc.library.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import global.sesoc.library.dao.ComplainRepository;
import global.sesoc.library.dto.Complain;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.SeatPenalty;
import global.sesoc.library.util.PageNavigator;

@Controller
public class ComplainController {
	@Autowired
	ComplainRepository repository;
	
	@RequestMapping(value = "complain")
	public String complain() {
		return "complain/complainMenu";
	}
	
	@RequestMapping(value = "complainBoard", method=RequestMethod.GET)
	public String complainBoard(
			@RequestParam(value = "currentPage", defaultValue = "1") int currentPage,
			@RequestParam(value = "searchItem", defaultValue = "title") String searchItem,
			@RequestParam(value = "searchWord", defaultValue = "") String searchWord, Model model
			) {
		
		int totalRecordCount = repository.getEveryComplaint(searchItem, searchWord);
		PageNavigator navi = new PageNavigator(currentPage, totalRecordCount);

		List<Complain> list = repository.selectAll(searchItem, searchWord, navi.getStartRecord(), navi.getCOUNT_PER_PAGE());
		
		model.addAttribute("list", list);
		model.addAttribute("searchItem", searchItem);
		model.addAttribute("searchWord", searchWord);
		model.addAttribute("totalRecordCount", totalRecordCount);
		model.addAttribute("navi", navi);
		model.addAttribute("currentPage", currentPage);
		
		return "complain/complainBoard";
	}
	
	@RequestMapping(value = "complainDetail", method=RequestMethod.GET)
	public String complainDetail(int compnum, Model model) {
		Complain complain = repository.selectOne(compnum);
		model.addAttribute("complain", complain );
		return "complain/complainDetail";
	}
	
	@RequestMapping(value = "deleteComplaint")
	public String deleteComplaint(int compnum) {
		Complain comp = repository.getComp(compnum);
		repository.deleteComplaint(compnum);
	
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("target", comp.getTarget());
		map.put("target2", comp.getTarget2());
		
		if(comp.getComptype() == 1) {
			List<Complain> list = repository.penaltyCheck2(map);
			
			if(list.size() < 5) {
				SeatPenalty sp = new SeatPenalty();
				sp.setPenaltytype(1);
				sp.setUserid(comp.getTarget());
				sp.setUserid2(comp.getTarget2());
				
				repository.deleteSP(sp);
			}
			
		} else if(comp.getComptype() != 1) {
			List<Complain> list = repository.penaltyCheck(comp.getTarget());
			
			if(list.size() < 5) {
				SeatPenalty sp = new SeatPenalty();
				sp.setPenaltytype(0);
				sp.setUserid(comp.getTarget());
				
				repository.deleteSP(sp);
			}
		}
		
		return "redirect:complainBoard";
	}
	
	@RequestMapping(value = "report")
	public String report() {
		return "complain/report";
	}
	
	@RequestMapping(value = "report", method = RequestMethod.POST)
	public String complain(Complain complain, int seatnum, HttpSession session,
			@RequestParam(value = "seatnum2", defaultValue = "0") int seatnum2
			, RedirectAttributes rattr
			) {
		
		List<Complain> list = null;
		List<Complain> list2 = null;
		Map<String, Object> map = new HashMap<String, Object>();
		
		Member m = (Member) session.getAttribute("login");
		
		if(m == null) {
			rattr.addFlashAttribute("message", "ログインしてから利用してください。");
			return "redirect:/";
		}
		
		String logid = m.getUserid();
		complain.setReguser(logid);
		
		String target = repository.getIdBySeatnum(seatnum);
		
		if(target == null) {
			rattr.addFlashAttribute("message", "当該の座席を利用している人がいません。");
			return "redirect:/";
		}
		
		complain.setTarget(target);
		
		if(seatnum2 != 0) {
			String target2 = repository.getIdBySeatnum(seatnum2);
			
			if(target2 == null) {
				rattr.addFlashAttribute("message", "当該の座席を利用している人がいません。");
				return "redirect:/";
			}
			
			complain.setTarget2(target2);
		}
		
		int result = 0;
		
		if(complain.getComptype() != 1) {
			Complain existComp = repository.compCheck(complain);
			
			if(existComp == null) {
				map.put("penaltytype", 0);
				map.put("userid", complain.getTarget());
				SeatPenalty existSP = repository.getSP(map);
				
				if(existSP == null) {
					result = repository.report(complain);
					rattr.addFlashAttribute("message", "コンプレインの受付が完了されました。");
					
				} else if(existSP != null) {
					repository.report(complain);
					repository.updateSPDate(existSP);
					rattr.addFlashAttribute("message", "コンプレインの受付が完了されました。");
				}
				
			} else if(existComp != null) {
				rattr.addFlashAttribute("message", "すでに同人物に対してコンプレインを提出しました。");
			}
			
		} else if(complain.getComptype() == 1) {
			Complain existComp = repository.compCheck(complain);
			
			if(existComp == null) {
				map.put("penaltytype", 1);
				map.put("userid", complain.getTarget());
				map.put("userid2", complain.getTarget2());
				SeatPenalty existSP = repository.getSP(map);
				
				if(existSP == null) {
					result = repository.report(complain);
					rattr.addFlashAttribute("message", "コンプレインの受付が完了されました。");
					
				} else if(existSP != null) {
					repository.report(complain);
					repository.updateSPDate(existSP);
					rattr.addFlashAttribute("message", "コンプレインの受付が完了されました。");
				}
				
			} else if(existComp != null) {
				rattr.addFlashAttribute("message", "すでに同人物に対してコンプレインを提出しました。");
			}
		}
		
		if(result == 1) {
			if(complain.getComptype() != 1) { 		//풍기문란 외의 경고
				list = repository.penaltyCheck(target);
				
				if(list.size() >= 5) {
					SeatPenalty existSP = repository.getSP(map);
					
					if(existSP == null) {
						SeatPenalty sp = new SeatPenalty();
						sp.setPenaltytype(0);
						sp.setUserid(complain.getTarget());
						repository.insertSP(sp);
						
					} else if(existSP != null) {
						repository.updateSPDate(existSP);
					}
				}
				
			} else if(complain.getComptype() == 1) { 	//풍기문란
				map.put("target", complain.getTarget());
				map.put("target2", complain.getTarget2());
				list2 = repository.penaltyCheck2(map);
				
				if (list2.size() >= 5) {
					SeatPenalty existSP = repository.getSP(map);
					
					if(existSP == null) {
						SeatPenalty sp = new SeatPenalty();
						sp.setPenaltytype(1);
						sp.setUserid(complain.getTarget());
						sp.setUserid2(complain.getTarget2());
						repository.insertSP(sp);
						
					} else if(existSP != null) {
						repository.updateSPDate(existSP);
					}
				}
			}
		}
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "myComplain")
	public String compToMe(Model model, HttpSession session) {
		Member m = (Member) session.getAttribute("login");
		String userid = m.getUserid();
		
		List<Complain> list = repository.myReportList(userid);
		model.addAttribute("list", list);
		
		List<Complain> list2 = repository.compAgainstMe(userid);
		model.addAttribute("list2", list2);
		
		return "complain/myComplain";
	}
}
