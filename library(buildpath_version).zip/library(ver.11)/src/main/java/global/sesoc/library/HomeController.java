package global.sesoc.library;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import global.sesoc.library.dao.BookRepository;
import global.sesoc.library.dto.Book;

@Controller
public class HomeController {

	@Autowired
	BookRepository Brepository;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		List<Book> bookList = Brepository.getNewBook();
		model.addAttribute("bookList", bookList);
		return "home";
	}
	
	@RequestMapping(value = "map", method = RequestMethod.GET)
	public String map() {
		return "map";
	}
	
}
