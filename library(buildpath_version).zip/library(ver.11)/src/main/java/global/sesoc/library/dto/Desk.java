package global.sesoc.library.dto;

public class Desk {
	private int desknum;
	private int location;

	public Desk() {
		// TODO Auto-generated constructor stub
	}

	public int getDesknum() {
		return desknum;
	}

	public void setDesknum(int desknum) {
		this.desknum = desknum;
	}

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Desk [desknum=" + desknum + ", location=" + location + "]";
	}
}
