package global.sesoc.library.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import global.sesoc.library.dto.Complain;
import global.sesoc.library.dto.Member;
import global.sesoc.library.dto.RentBook;

@Repository
public class MemberRepository implements MemberDao {
	@Autowired
	SqlSession session;
	
	@Override
	public Member selectOne(Member member) {
		MemberDao dao = session.getMapper(MemberDao.class);
		Member m = dao.selectOne(member);
		return m;
	}

	@Override
	public int insertJoin(Member member) {
		MemberDao dao = session.getMapper(MemberDao.class);
		int result = dao.insertJoin(member);
		return result;
	}
	
	@Override
	public int updatePwd(Member member) {
		MemberDao dao = session.getMapper(MemberDao.class);
		int result = dao.updatePwd(member);
		return result;
	}
	
	@Override
	public int deleteMember(Member member) {
		MemberDao dao = session.getMapper(MemberDao.class);
		int result = dao.deleteMember(member);
		return result;
	}
	
	@Override
	public int updateUserInfo(Member member) {
		MemberDao dao = session.getMapper(MemberDao.class);
		int result = dao.updateUserInfo(member);
		return result;
	}
	
	@Override
	public List<RentBook> selectRentbook(String userid) {
		MemberDao mapper = session.getMapper(MemberDao.class);
		List<RentBook> list = mapper.selectRentbook(userid);
		return list;
	}

	@Override
	public List<Complain> selectComplain(String userid) {
		MemberDao mapper = session.getMapper(MemberDao.class);
		List<Complain> list = mapper.selectComplain(userid);
		return list;
	}
}
