package global.sesoc.library.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import global.sesoc.library.dto.Desk;
import global.sesoc.library.dto.PortName;
import global.sesoc.library.dto.Reliability;
import global.sesoc.library.dto.RentSeat;
import global.sesoc.library.dto.Seat;
import global.sesoc.library.dto.SeatPenalty;
import global.sesoc.library.dto.SeatUser;
import global.sesoc.library.dto.Statistics1;
import global.sesoc.library.dto.Statistics2;
import global.sesoc.library.dto.SubUserInfo;
import global.sesoc.library.dto.WaitPaper;

@Repository
public class StudyRepository implements StudyDao {
	@Autowired
	SqlSession session;
	
	@Override
	public List<Desk> getAllDesk(int location) {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<Desk> list = dao.getAllDesk(location);
		return list;
	}

	@Override
	public List<Seat> getAllSeat(int location) {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<Seat> list = dao.getAllSeat(location);
		return list;
	}

	@Override
	public List<WaitPaper> getAllWait(String now) {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<WaitPaper> list = dao.getAllWait(now);
		return list;
	}
	
	@Override
	public List<WaitPaper> getUnableWait(String now) {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<WaitPaper> list = dao.getUnableWait(now);
		return list;
	}

	@Override
	public List<WaitPaper> getAbleWait(String now) {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<WaitPaper> list = dao.getAbleWait(now);
		return list;
	}

	@Override
	public SubUserInfo getSubUserInfo(int seatnum) {
		StudyDao dao = session.getMapper(StudyDao.class);
		SubUserInfo sui = dao.getSubUserInfo(seatnum);
		return sui;
	}

	@Override
	public int insertRentSeat(RentSeat rs) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.insertRentSeat(rs);
		return result;
	}

	@Override
	public RentSeat getRentPaper(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		RentSeat rs = dao.getRentPaper(userid);
		return rs;
	}
	
	@Override
	public List<Seat> getAbleSeat() {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<Seat> ableSeat = dao.getAbleSeat();
		return ableSeat;
	}
	
	@Override
	public List<WaitPaper> getAllPaper() {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<WaitPaper> wp = dao.getAllPaper();
		return wp;
	}
	
	@Override
	public int insertWait(WaitPaper waitpaper) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.insertWait(waitpaper);
		return result;
	}
	
	@Override
	public RentSeat getUsingSeat(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		RentSeat rs = dao.getUsingSeat(userid);
		return rs;
	}
	
	@Override
	public WaitPaper getWaitPaper(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		WaitPaper wp = dao.getWaitPaper(userid);
		return wp;
	}
	
	@Override
	public WaitPaper getWaitInfo(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		WaitPaper wp = dao.getWaitInfo(userid);
		return wp;
	}
	
	@Override
	public int updateSeatStatus(Map<String, Object> map) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.updateSeatStatus(map);
		return result;
	}
	
	@Override
	public int returnSeat(Map<String, Object> map) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.returnSeat(map);
		return result;
	}
	
	@Override
	public int updateAbleWait(WaitPaper wp) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.updateAbleWait(wp);
		return result;
	}
	
	@Override
	public int useWait(WaitPaper wp) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.useWait(wp);
		return result;
	}
	
	@Override
	public List<Statistics1> getSta1() {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<Statistics1> list = dao.getSta1();
		return list;
	}
	
	@Override
	public Statistics2 getSta2(Statistics2 sta2) {
		StudyDao dao = session.getMapper(StudyDao.class);
		Statistics2 statistics2 = dao.getSta2(sta2);
		return statistics2;
	}
	
	@Override
	public int returnSeat2(int seatnum) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.returnSeat2(seatnum);
		return result;
	}
	
	@Override
	public String getSeatUserid(int seatnum) {
		StudyDao dao = session.getMapper(StudyDao.class);
		String userid = dao.getSeatUserid(seatnum);
		return userid;
	}
	
	@Override
	public List<Seat> getEverySeat() {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<Seat> list = dao.getEverySeat();
		return list;
	}
	
	@Override
	public int regAbstime(int seatnum) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.regAbstime(seatnum);
		return result;
	}
	
	@Override
	public int regBaseData(int basedata) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.regBaseData(basedata);
		return result;
	}
	
	@Override
	public List<PortName> getPortNames() {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<PortName> list = dao.getPortNames();
		return list;
	}
	
	@Override
	public int insertPortNames(PortName portname) {
		StudyDao dao = session.getMapper(StudyDao.class);
		int result = dao.insertPortNames(portname);
		return result;
	}
	
	@Override
	public PortName getPortName(int seatnum) {
		StudyDao dao = session.getMapper(StudyDao.class);
		PortName portname = dao.getPortName(seatnum);
		return portname;
	}
	
	@Override
	public Reliability getReliability() {
		StudyDao dao = session.getMapper(StudyDao.class);
		Reliability reliability = dao.getReliability();
		return reliability;
	}
	
	@Override
	public SeatPenalty getSP0(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		SeatPenalty sp0 = dao.getSP0(userid);
		return sp0;
	}
	
	@Override
	public List<SeatPenalty> getSP1(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		List<SeatPenalty> sp1 = dao.getSP1(userid);
		return sp1;
	}
	
	@Override
	public SeatUser checkPartner(int seatnum) {
		StudyDao dao = session.getMapper(StudyDao.class);
		SeatUser su = dao.checkPartner(seatnum);
		return su;
	}
	
	@Override
	public WaitPaper getAbleWaitById(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		WaitPaper wp = dao.getAbleWaitById(userid);
		return wp;
	}
	
	@Override
	public String getSendPhone(String userid) {
		StudyDao dao = session.getMapper(StudyDao.class);
		String phone = dao.getSendPhone(userid);
		return phone;
	}
}
